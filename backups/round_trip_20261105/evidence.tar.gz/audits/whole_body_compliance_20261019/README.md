# AMIR whole-body compliance: CP監査と実装記録（2026-10-19 JST）

**追加CP-13：[1 m前進・1 m後退の専用コマンド](cp13_round_trip/README.md)。最終の正常往復・後退中F/T異常停止・GUI一括実行が合格。両台ゼロ指令まで16.244 ms、65試験が通過。カメラ自由操作、Followerの局所入力境界、既存source・モデル・資格を保持。整数時刻比較の補正とイベント起動は往復用へ分離。過去の実際のclock／センサ時刻ずれ等の安定性課題は継続する。**

**最新表示設定：[カメラ自由操作への変更](cp12_free_camera/README.md)。ユーザー指示により固定初期視点・自動追従を削除。マウス操作を保持し、起動テスト24件と独立GUI実起動を確認。0.1 m/s・3 mと安全条件は維持。CP-12の安定受入は未完了。**

**継続中：[CP-12 GUI付き0.1 m/s・3 m搬送と表示カメラ修正](cp12_gui_stability/README.md)。GUI正常4実行と定速F/T異常2実行が合格。最終payload定速GT平均0.099995473 m/s、両台ゼロ指令まで40.199 ms。別1実行は注入前の制御ノード更新断約120 msで停止し、安定受入は未完了。カメラの要求順・座標変換・実pose収束確認を修正し、制御・安全条件・元105モデル／YAML・Followerの局所入力境界を維持。起動境界24試験を追加確認し、前CPの295回帰証跡とsource一致を照合。間欠停止の原因特定とCP-8の回転未整定は継続課題。実機は対象外、Humble／Fortressを維持。**

**2026-10-23：[CP-11 局所把持力維持と低・中速の受入](cp11_grip_maintenance/README.md)。各台が自機の把持監視だけから有界な閉じ補正を行うopt-in機能を追加。静止・0.1 m／0.01 m/s・3 m／0.1 m/s・通常1 m／0.005 m/s・GUI入口と走行中4異常の受入9実行、263回帰テスト、27照合が通過。通常1 mの物体GT移動は0.994398 m。元105モデル／YAML、アーム／台車・既存安全アルゴリズム、Followerの購読境界を保持。追加画面試験では許可前のrelay heartbeat待機がtimeoutし、起動の再現性は未解明。搬送画像もロック画面のため未確認。高速公開資格は閉じたまま。次のCP-12は起動不安定の確認と、保持補正を接続した220 m／1 m/s正常完走・定速異常停止の再検証。実機は対象外、Humble／Fortressを維持。**

**2026-10-23：[接触把持搬送のGUI・進捗表示改善](gui_visibility_20261023/README.md)。1 m / 0.005 m/sのGUI付き搬送を確認し、payload実移動0.994302 m、両台停止・購読境界成立。専用の側方視点と段階・変位表示を追加した。終了時に内側シェルからGUI本体が残る不具合を直接起動へ変更し、最終版の短距離搬送とGUI単独終了で残存ゼロを確認。76試験・18最終照合が通過。元105モデル／YAMLと制御・安全sourceを保持。高速搬送・回転の未達条件は継続する。**

仕様書は設計入力として読み、例のAPI・数値・インストールコマンドを実環境へそのまま適用していない。ユーザーの最優先条件を優先する。過去の `GAZEBO_*REPORT.md` は参考資料であり、今回の実行結果と区別する。

**2026-10-23：[CP-10 1.0 m/s到達検証・連続搬送の未達条件](cp10_speed_1ms/README.md)。距離延長のユーザー回答を受け、接触把持で1 m/sに到達した。17.48 sim秒のpayload平均GT速度は0.999531 m/s、arm偏差最大0.32845 mm。1 m/s定速中のF/T NaNでも両台停止・自動再開なしを確認した。ただし220 mの最終減速で片指7.96037 Nが既存保持判定8 Nを下回り中断し、正常完走は未合格。高速公開入口は未有効化、通常の1 m・0.005 m/sの入口と上限を維持する。222テスト、到達・異常停止の25照合が通過。元105モデル／YAMLを維持し、通常の配分・recentringは開始時snapshotとbit一致。**

**2026-10-22追記：[1 m目標への拡張・実行コマンド](cp9_1m/README.md)。`compliance_contact_transport.launch.py` の既定目標を1.0 m、速度を0.005 m/sへ更新し、接触把持の協調搬送・整定・両台停止を確認した。物体GT X移動は0.994423 mで、encoder目標との差5.577 mmは残る。加速中のF/T非有限値で両台停止・自動再開なし、198テスト・28照合が通過。元105モデル／YAMLと安全sourceを維持し、followerのleader／TF／GT購読なし。旧段階のログ・失敗例も保存している。**

**2026-10-20の状態：[CP-9 接触把持の安全gate接続・低速直進報告](cp9_transport/README.md)。既存gate／最終interlockへ引き渡し、leaderだけの0.1／1 mm目標でnative contact搬送を検証。物体GT移動は0.07941／0.90009 mm。フォロワはown F/T・arm・baseと共有安全Boolだけを使い、leader位置／速度／目標／TF／GTを購読しない。直進2条件＋走行中異常8種の最終10実行、298テスト、212照合が通過。両台停止・入力復旧後の再開なし、清掃停止前の実controller inactiveを確認。13 source追加、既存source600保持・入口1行追加、元105モデル／YAMLとtracked差分保持。Humble／Fortressを維持し、実機はユーザー指示で対象外。native後退・横・ヨー／中心指定は未受入。[CP-8](cp8/README.md)の協調ヨー／中心指定の未整定は未解決。前段階の[CP-9静止接触把持](cp9/README.md)、[CP-7停止比較](cp7/README.md)も保存。**

以下のCP-0〜CP-2本文と末尾の状態表は、各段階を実施した当時の記録。現在の進捗・残課題は冒頭の更新と各CPの報告を参照する。手順書のCP-9実機移行はユーザー指示により対象外であり、追加のCP-9接触搬送以降とは区別する。

## CP-0：監査完了、CP-1へ進める

変更：このREADME、`tools/amir_cp_audit.py`、`cp0/` の監査証跡のみ。モデル・制御ソースはこの段階では未変更。

- Ubuntu **22.04.5**、ROS 2 **Humble**、Gazebo Sim **Fortress 6.16.0**。Jazzy/24.04/Harmonicとは異なる。環境更新は実施しない。Classic **11.10.2** も存在するが対象launchでは使用しない。
- `gz_ros2_control=0.7.20`、controller-manager **2.54.0**、mecanum-drive-controller **2.52.1**、ros-gz-bridge **0.244.22**。`gz sim --versions` は Invalid arguments、正しい既存コマンドは `ign gazebo --versions`。
- workspaceには30パッケージ。全package.xmlと依存は `cp0/packages.json`、ソースhashは `cp0/source_files.json` に保存。
- 既存の変更・削除・未追跡ファイルが多数ある。既存変更は取り消さない。開始時tracked差分は `cp0/preexisting.patch`、状態は `cp0/preexisting_status.txt`。仕様書内の一括バックアップコミット例は実施していない（既存ユーザー変更を本変更に混ぜない）。

### 確認した実ファイル

|用途|workspace相対パス（src/humbleble_ws/以下）|
|---|---|
|ロボット単体launch|amir740_ros/amir_gazebo/launch/robot_bringup.launch.py|
|既存2台固定把持|cooperative_transport_bringup/launch/simulation.launch.py|
|既存接触把持|cooperative_transport_bringup/launch/friction_simulation.launch.py|
|既存局所Follower構成|amir_follower_control/launch/coop_transport.launch.py|
|シミュレーションURDF入口|amir740_ros/amir_description/urdf/amir_mecanum3_sim.xacro|
|アーム本体|amir740_ros/amir_description/urdf/amir_for_rover.xacro|
|台車とGazebo plugin|mecanumrover3_ros2/mecanumrover_description/urdf/mecanum3.{xacro,gazebo}|
|台車hardware interfaces|mecanumrover3_ros2/mecanumrover_description/urdf/mecanum3_ros2_control.xacro|
|台車controllers YAML|mecanumrover3_ros2/mecanumrover_description/params/controllers.yaml|
|アームcontrollers YAML|amir740_ros/amir_gazebo/config/arm_controllers.yaml|
|机SDF（固定／摩擦）|cooperative_transport_description/models/cooperative_payload{,_friction}/model.sdf|
|world|cooperative_transport_gazebo/worlds/cooperative_transport{,_contact,_friction}.sdf|

### 実ジョイントと物理値

|joint|URDF範囲 rad|velocity rad/s|effort Nm|
|---|---|---|---|
|Joint_1|−2.96706 … 2.96706|1|33|
|Joint_2|0 … 2.356194|1|22|
|Joint_3|−2.792527 … 0|1|26|
|Joint_4|−2.094395 … 1.308997|1|13|
|Joint_5|−2.75762 … 2.75762|2|4|
|Gripper|−1.047198 … 0.261799|2|1.4|

車輪：`front_left_joint`, `front_right_joint`, `back_left_joint`, `back_right_joint`。velocity command／position+velocity state。ローラ個別jointはなく円筒接触と異方性摩擦による近似。アームはposition command／position+velocity state、JTC。グリッパAPIは `gripper_controller/gripper_cmd` action。実JointStateのmimic名はURDFの名前と異なる `*_mimic` が含まれる（全一覧はruntime.json）。effortは全関節 **NaN**、監査JSONではnullとして保存し、実トルクとして利用しない。

生成URDF合計質量 **32.876304 kg**。全リンク慣性の固有値は正。ただし正定値だけでは物理的妥当性の保証にならない。固定机は主リンク8 kg＋接続リンク各0.01 kg＝**8.02 kg**、摩擦机は**0.5 kg**。両方の箱形状は1.20×0.03×0.08 m。質量・慣性・原点の全値は `cp0/model_inventory.json`。

### メーカー仕様との照合

出典：[AMIR740](https://www.vstone.co.jp/products/amir740/index.html)、[メカナムローバーVer.3.0](https://www.vstone.co.jp/products/wheelrobot/ver.3.0_mecanum.html)（今回参照）。

|項目|メーカー／仕様書|現在のモデル・設定|判断|
|---|---|---|---|
|J1/J5範囲|±170°／±158°|ほぼ一致|丸め差|
|J2|−135°…0°|0°…135°|符号差、上書き禁止|
|J3|0°…160°|−160°…0°|符号差、上書き禁止|
|J4|−75°…120°|−120°…75°|符号差、上書き禁止|
|アーム最大速度|60°/s|J1–4=1 rad/s、J5=2 rad/s|特にJ5は公称を超える。実機用に流用不可|
|可搬重量|2 kg/arm|固定机主リンク8 kg|適合未確認。8 kgを安全な対象として認定しない|
|タイヤ径|152 mm|radius=0.076 m|幾何値一致、有効接触半径は実測対象|
|台車重量|約17.9 kg|base_linkだけで20 kg|モデル全体質量とは区別、実機同一視不可|
|輪間寸法|外形323×392 mm|controller lx+ly=0.24 m|外形から決定しない。生成URDFの変換で照合する|

追加の幾何監査 `cp0/geometry.json`：base_footprintで車輪中心は概ね x=±0.120 m、y=±0.115 m、z=0.076 m。したがって **lx+ly≈0.235 m**、YAMLの0.24 mは約2.13%大きい。CP-1では元の設定を維持し差を実測する。HOME=(0,1.4,−1.6,0.2,1.570796)で4D (x,y,z,yaw) Jacobianは **rank 3**、最小特異値≈1.03e−16。5関節だから4D全成分が独立に実現できるとは扱わない。

### 実起動結果とAPI

```bash
source install/setup.bash
ROS_DOMAIN_ID=101 IGN_PARTITION=amir_cp0_20261019 \
RMW_FASTRTPS_PUBLICATION_MODE=ASYNCHRONOUS \
python3 tools/amir_cp_audit.py \
  --output audits/whole_body_compliance_20261019/cp0/single \
  --robots audit_robot --timeout 100 -- \
  ros2 launch amir_gazebo robot_bringup.launch.py \
  namespace:=audit_robot headless:=true enable_d435:=false enable_lidar:=false
```

モデル未修正で単独起動 **成功**。4 controller全てactive。関節状態1023件、encoder odometry890件、GT odom294件、clock2057件、TF407件＋static1件を取得。起動ログ `cp0/single/launch.log`、ノード別入出力・実サンプル・TF木は `cp0/single/runtime.json`、Gazebo topics/actionsも保存。終了時SIGINTのKeyboardInterrupt／exit −2は試験終了操作によるもの。

|API（/audit_robot/以下）|型／意味|
|---|---|
|rover_twist|Twist、既存relayへの入力|
|mecanum_drive_controller/reference_unstamped|Twist、実コントローラ入力|
|arm_controller/joint_trajectory|trajectory_msgs/msg/JointTrajectory|
|arm_controller/follow_joint_trajectory|control_msgs/action/FollowJointTrajectory|
|joint_states|sensor_msgs/msg/JointState|
|mecanum_drive_controller/odometry|nav_msgs/msg/Odometry、車輪由来|
|odom|nav_msgs/msg/Odometry、**Gazebo真値**|
|ft_sensor|WrenchStamped bridgeはあるが既定worldで実データ **0件**|

TFは `odom → base_footprint → base_link → link0_1 → … → gripper_base_1 → tcp_link`。TF topicだけnamespace分離しframe IDは共通のまま。既存 `/odom/tf` はGTであり制御用TFと混ぜない。TCP固定原点はgripper_base_1から(0, 0.0795, 0)m。F/Tは **Joint_5** のchild側、100 Hz、child_to_parent。推奨の専用固定FT jointとは異なる。既定worldにForceTorque systemがなく、実F/T検証はCP-2のゲート。

### 設計差分・未解決TODOと次への条件

CP-0完了条件「現行モデルの単独起動、変更箇所特定」を満たす。CP-1へ進む。

- CP-1：`/leader` `/follower`、ユニークなframe ID、encoder由来TF、GT bridgeは別の評価launchに分離。机は既存0.5 kgモデルを支持台上で使用し、把持はCP-2。
- 既存 `distributed_straight.py` は物体観測を使うため自律Followerとして採用不可。既存 `amir_follower_control/node.py` は局所FT/JointState/encoder/grasp/clockのみだが、較正証跡と `amir2` 設定が必要。新namespaceで再検証する。
- フォロワ入力whitelistはtopic名だけでなく発信元とremapも確認する。GTを同名topicに流す構成を認めない。
- 力上限・指荷重上限・ゲインは既存試験値でありメーカー定格ではない。今回の新構成に自動採用しない。
- 両機停止はFollowerの局所FAULTだけでは不足。独立停止経路、Leaderの停止、watchdog、joint limitでの停止をCP-7までに実測し、それ以前の自律搬送合格を宣言しない。
- 環境移行は別workspaceまたは隔離環境でJazzy/Harmonic互換性を確認してから行う。今回OS・ROS・Gazebo更新なし。

既存FollowerのcoreとROS安全ゲートの試験は `ROS_DOMAIN_ID=103 python3 -m pytest -q src/humbleble_ws/amir_follower_control/test/{test_core,test_ros_safety}.py` で **55 passed**（`cp0/existing_follower_tests.log`）。過去の物理較正certificateを新namespaceへ流用できるという意味ではない。

## CP-1：合格

修正ファイル：

- `amir_gazebo/launch/robot_bringup.launch.py`：任意の `tf_frame_prefix`（既定空）と `bridge_ground_truth`（既定true）のみ追加。開始前からあった `robot_description_file` 変更は保持。
- `cooperative_transport_bringup/launch/compliance_cp1.launch.py`：追加構成。leader/follower、支持台と既存0.5 kg机1個、独立controllers。生成URDF/YAML/SDFをrun_directoryへ保存。
- `cooperative_transport_bringup/launch/compliance_evaluation.launch.py`：任意の評価専用GT bridge。コマンド出力なし。
- `cooperative_transport_bringup/package.xml`：追加launchが使用するxacro/YAML/モデルの依存を明示。
- `tools/amir_cp1_motion.py`：評価専用の独立運動確認。両機GTを読むが制御ノードには組み込まない。

```bash
source install/setup.bash
colcon build --symlink-install --packages-select amir_gazebo cooperative_transport_bringup
# 端末1（自動運動なし）
ROS_DOMAIN_ID=105 IGN_PARTITION=amir_cp1_run3_20261019 \
RMW_FASTRTPS_PUBLICATION_MODE=ASYNCHRONOUS \
python3 tools/amir_cp_audit.py --output audits/whole_body_compliance_20261019/cp1/runtime \
  --robots leader follower --timeout 350 \
  --finish-file audits/whole_body_compliance_20261019/cp1/run3_done -- \
  ros2 launch cooperative_transport_bringup compliance_cp1.launch.py \
  run_directory:=/home/dars5070/ros2_humble_ws/audits/whole_body_compliance_20261019/cp1/run3_generated
# 端末2（CP-1の無把持scene専用）
ROS_DOMAIN_ID=105 IGN_PARTITION=amir_cp1_run3_20261019 \
RMW_FASTRTPS_PUBLICATION_MODE=ASYNCHRONOUS \
python3 tools/amir_cp1_motion.py --output audits/whole_body_compliance_20261019/cp1/motion_run3 \
  --finish-file audits/whole_body_compliance_20261019/cp1/run3_done
```

ビルド2 packages成功（`cp1_build.log`）。初回は起動時ListControllers応答送信のRCLErrorでGazebo終了（`cp1/failed_startup_01`）。監査のサービス要求をencoder出現後／1秒間隔へ制限し、既存の単体起動手順を使用。次の試験では検証側がgripperのactive前に判定したため早期終了（`cp1/early_verifier_02`）；検証側に4 controllers待機を追加。失敗記録は保持。

TF実測でinstalled mecanum controllerの出力は `~/tf_odometry` と確認。これをロボットのtf topicへ明示remapする。`/leader/...`、`/follower/...` のframe IDをRSPとencoder odometryで揃える。GTのGazebo topicは `/experiment/<robot>/ground_truth/*`、ROS bridgeは別launchのみで起動。自律Followerはまだ起動しない。

残るTODO：旋回定量誤差、接触有効半径と滑りの分離。CP-2では局所FTの実データと座標／符号、把持静止、欠測監視を確認する。ユーザー回答により確認済み荷重資料はない。安全閾値を既存試験値で確定せず、自律搬送は必要な根拠と停止試験が揃うまで無効とする。

実測結果：`cp1/motion_run3/motion.json` の **30/30項目合格**。両ロボットとも vx=.01 m/s×1.5秒→GT 0.014999994 m、vyもGT 0.014999994 m。yaw=.02 rad/s×1.5秒→encoder .0300 rad、GT **.0280359 rad**（約6.55%差；寸法差だけに帰属せず、滑り等を含む未解決の定量誤差）。アーム5関節の+.01 rad／復帰、グリッパ−.9／−1.0 rad、相手機の静止、台車停止を確認。最大アーム目標誤差≈7.41e−8 rad。これは無荷重・低速の結果。

TF最終構成を別起動 `cp1/final_tf` で再確認：両機4 controller active、`leader/odom → leader/base_footprint` と `follower/odom → follower/base_footprint` が各自のmecanum controller発信で存在。RSPの全frame IDも対応prefixで一致。グローバル `/tf` と制御namespaceのGT odom publisherは存在しない。従ってCP-1完了条件を満たしCP-2へ進む。較正用データを後続CPへ流用しない。

追加引数を省略した既存launchの回帰起動も成功（`cp1/original_regression`）：4 controller active、旧 `odom → base_footprint` とGT odomを維持。CP-1後に追加したfixture引数はすべて既定false。

## CP-2：センサ・前処理・段階A静止合格、搬送開始条件は未確定

### 修正・追加ファイル

- `cooperative_transport_bringup/launch/compliance_cp1.launch.py`：任意のForceTorque system、較正fixture、拘束fixtureを追加（すべて既定false）。拘束fixtureの姿勢・支持台高さ・spawn位置は生成URDFの初期関節値、FK、既存SDFの把持フレームから算出。
- `cooperative_transport_bringup/launch/compliance_cp2_sensors.launch.py`：無把持較正専用。既存のbounded external-wrench pluginをfollowerへ適用。
- `cooperative_transport_bringup/launch/compliance_cp2_constraint.launch.py`：段階A専用。明示要求までは拘束を作らず、支持台を保持。
- `cooperative_transport_bringup/package.xml`：fixtureと新しい局所制御packageへの依存。
- 新規 **`src/humbleble_ws/amir_compliance_control/`**：`package.xml`, `setup.py`, `setup.cfg`, `resource/amir_compliance_control`, `README.md`, `launch/wrench_preprocessor.launch.py`, `amir_compliance_control/{__init__,wrench,wrench_preprocessor}.py`, `test/test_wrench_pipeline.py`。
- `tools/amir_cp2_probe.py`, `tools/amir_cp2_preprocessor_check.py`, `tools/amir_cp2_constraint_check.py`：独立した評価・試験用ツール。自律制御packageからimportされない。

### 制御／評価の依存境界

新制御package `amir_compliance_control` の依存はrclpy／numpy／ROSメッセージ／launchのみ。旧 `amir_follower_control` やGazebo・評価packageに依存しない。既存Follower packageには評価・bringupへの依存があるため、そのまま新制御系の依存元にしていない。

実ROSグラフで前処理の購読は **`/clock`, `/follower/ft_sensor`, `/follower/joint_states`, `/follower/mecanum_drive_controller/odometry` の4件のみ**。Leader・目標・GT・TFの購読なし。TFは自機関節から算出。前処理ノードは運動コマンドを一切発行しない。

レンチをセンサ原点からモデルTCPへモーメント移送し、baseと平行な軸へ回転する。出力frameを `follower/grasp_aligned` とし、原点TCP／軸baseのTFも同じstampで自機tfへ送信。TCP回りのモーメントをbase原点回りと誤表示しない。raw変換出力 `wrench_at_grasp_raw` はbiasを引く前、`wrench_filtered` は明示 `tare_wrench` 後のみ出力する。

### 実行コマンド（workspace直下）

```bash
source install/setup.bash
colcon build --symlink-install --packages-select amir_compliance_control cooperative_transport_bringup

# センサscene：端末1
ROS_DOMAIN_ID=108 IGN_PARTITION=amir_cp2_20261019 RMW_FASTRTPS_PUBLICATION_MODE=ASYNCHRONOUS \
python3 tools/amir_cp_audit.py --output audits/whole_body_compliance_20261019/cp2/runtime \
  --robots leader follower --timeout 200 \
  --finish-file audits/whole_body_compliance_20261019/cp2/probe_done -- \
  ros2 launch cooperative_transport_bringup compliance_cp2_sensors.launch.py \
  run_directory:=/home/dars5070/ros2_humble_ws/audits/whole_body_compliance_20261019/cp2/generated
# 端末2：力±.5 N／モーメント±.05 Nmの同定入力（安全閾値ではない）
ROS_DOMAIN_ID=108 IGN_PARTITION=amir_cp2_20261019 RMW_FASTRTPS_PUBLICATION_MODE=ASYNCHRONOUS \
python3 tools/amir_cp2_probe.py \
  --urdf audits/whole_body_compliance_20261019/cp2/generated/follower.urdf \
  --output audits/whole_body_compliance_20261019/cp2/probe \
  --finish-file audits/whole_body_compliance_20261019/cp2/probe_done
```

上記のfinish-fileは試験完了時に作られる。**同じ試験を再実行する場合は新しいoutput／finish-fileを指定するか、終了済みの当該finish-fileだけを削除する**。URDFにcontroller YAMLの絶対パスを含むため、run_directoryを変えた場合はhashも変わる。較正証跡を書き換えて流用せず、そのsceneでprobeを再実行する。

前処理の実行は別sceneを同じ `cp2/generated` で起動し（実測domain=110、partition=`amir_cp2_processing_20261019`）、auditの終了条件を `cp2/processing_done` にする。もう一方の端末で同domain／partitionを指定して次を実行した。

```bash
python3 tools/amir_cp2_preprocessor_check.py \
  --urdf audits/whole_body_compliance_20261019/cp2/generated/follower.urdf \
  --certificate audits/whole_body_compliance_20261019/cp2/probe/calibration.json \
  --output audits/whole_body_compliance_20261019/cp2/processing_check \
  --finish-file audits/whole_body_compliance_20261019/cp2/processing_done
```

拘束静止fixtureの実測実行はdomain=113、partition=`amir_cp2_constraint_retry_20261019`。auditで `compliance_cp2_constraint.launch.py` を起動、run_directory=`cp2/constraint_generated`、終了条件=`cp2/constraint_retry_done`。同domain／partitionの別端末で以下を実行した。

```bash
python3 tools/amir_cp2_constraint_check.py \
  --run-directory audits/whole_body_compliance_20261019/cp2/constraint_generated \
  --output audits/whole_body_compliance_20261019/cp2/constraint_check \
  --finish-file audits/whole_body_compliance_20261019/cp2/constraint_retry_done
```

### ログと結果

|検証|今回の結果|証跡（このREADMEからの相対パス）|
|---|---|---|
|6軸の正負既知レンチ|**12/12合格**、gain≈1.0、sign=+1、2800点|`cp2/probe/calibration.json`, `samples.jsonl`|
|実F/T frame|`follower/Joint_5/wrist_ft_sensor`|同上|
|未把持重力|下流質量0.225931 kg → −2.21638311 N、実測−2.2163831100 N|`cp2/gravity_check.json`|
|raw→FK→TCP移送、tare、LPF|実データで合格|`cp2/processing_check/result.json`|
|F/T欠測|対象domainの自機bridgeだけをSIGSTOP、INVALIDとfiltered停止を確認。必ずSIGCONTで復旧|同上|
|欠測からの復帰|再tare前にfilteredが再開しないことを確認|同上|
|購読境界|自機3トピック＋clockだけ|同上|
|段階A静止|拘束成立確認→支持台撤去→10秒保持、最後8秒のGT xyz変動は出力精度内0|`cp2/constraint_check/result.json`, `object_poses.json`|
|荷重整合|追加質量0.52 kg、予測5.10120 N、両手反力差分合計5.10118 N|同上|
|推定関節荷重|保守的な静的上界がURDF effort以下。最大J2≈3.854 Nm（URDF22 Nm）|`cp2/constraint_check/samples.jsonl`|
|数学／異常入力／購読＋既存回帰|**63 passed**（新規8＋既存55）|`final_unit_tests.log`|

拘束fixtureは既存の固定モデルの主リンクを既存摩擦モデルと同じ0.5 kgへ変更、主リンク慣性を同倍率に変更した派生SDF。接続リンク各0.01 kgを含む総質量は **0.52 kg**。元の8.02 kgモデルは未変更。指を閉じて摩擦で支えている結果ではない。

初回の静止試験ツールは各callbackで重いモデル計算を行って受信が遅れ、F/T／関節時刻の不整合で支持台撤去前に中断した（`constraint_*_timing_failure`）。計算・記録を20 wall Hzに限定し、その間に受信callbackを処理するよう修正。同じ50 ms鮮度／20 ms整合条件のまま再試験し合格。これは静止評価ツールであり、100 Hzの安全監視性能を主張しない。

### 未解決TODOと次のCPへ進む条件

1. **荷重の警告／停止値の根拠がない。** センサ較正の±.5 N／±.05 Nm、既存50 N等の設定、指8 N等の過去試験値を安全限界にしない。今回のモデルjoint effortによる静的上界は、慣性・摩擦・実モータートルクを含まない。実JointState effortはNaNのまま。
2. **両機を止める実装・故障注入試験が未完了。** 前処理の出力停止と評価ツールのzero/holdは、自律運転で両機停止を保証する系統の代わりにならない。Leaderが正常なままFollower欠測になったケース、joint limit、時計停止／逆行、停止信号の欠測を含めて確認する必要がある。
3. 誤った安全閾値を確定しないという最優先条件に従い、**CP-3以降の搬送を有効化していない**。次へ進むには、Gazebo上の動的荷重判定の観測・モデル根拠、実験用限界と実機定格の区別、独立した両機停止経路を先に具体化して検証する。仕様書でCP-7にまとめた安全項目のうち、搬送開始に必須の部分は前倒しする必要がある。
4. 初期姿勢の4D rank欠損、yawの約6.55%誤差、実TCPと指接触中心の一致、接触把持、長距離運搬、帯域分離の実搬送検証は未解決。静止拘束の結果から推定して合格にしない。

## CP-2完了当時のCP-3〜CP-9の状態（履歴）

|CP|今回の修正／実行|未解決TODO／進行条件|
|---|---|---|
|CP-3 比較ベースライン|未着手・未実行|上記の搬送開始安全ゲート、同一条件の独立位置制御・遅延注入・CSV仕様|
|CP-4 Leaderのみ目標|未着手・未実行|CP-3後、Leader目標生成と局所Follower入力・TF依存の実グラフ試験|
|CP-5 腕アドミッタンス|未着手・未実行|CP-4後、初期rank欠損の扱い、DLS・ソフト制限、実外力応答|
|CP-6 台車再中心化|未着手・未実行|CP-5後、腕／台車帯域分離、持続偏差回復、実直進搬送|
|CP-7 安全・遅延評価|未完・搬送前必須部分を前倒し要|動的荷重根拠と両機停止の故障注入試験、比較バッチ|
|CP-8 全身配分|未着手・未実行|CP-7後、全身Jacobianの数値微分、制約付き配分と追加動作|
|CP-9 実機|別フェーズ・未実行|実機センサ／定格／非常停止／接触把持の根拠。今回のシミュレーション証跡では代替不可|

OS、ROS distro、Gazebo版、既存の既定モデル・既存制御は移行／置換していない。Gitコミットは作成していない。今回の変更と開始前の変更はmanifest・hashで区別する。

最終確認ではCP-2用の追加引数をすべてfalseにしてCP-1生成物を再生成し、world／controller YAML／URDF（証跡directoryの絶対パス差を除く）がCP-1合格時と同一であることを確認（`cp1/default_invariance.json`）。開始前に存在したソースで変更したものは `robot_bringup.launch.py` とbringupの `package.xml` の2ファイルのみ（`changed_preexisting_sources.json`）。他は追加ファイル。ビルド／試験用のGazeboプロセスは終了済み。

> 続報：[GUI付き搬送と表示カメラ修正](../cp12_gui_stability/README.md)。正常4実行・定速F/T異常2実行が合格、別1実行は注入前の間欠停止で不合格。表示helperだけを修正し、制御・安全条件は維持。安定受入は継続中。以下は本追加検証前の記録。

# CP-12：3 m・0.1 m/s接触協調搬送、GUI完走は未達

ユーザーの最新指定 **0.1 m/s** を対象に、画面なし正常搬送、定速中のF/T異常停止、公開一括起動の画面なし搬送・整定まで確認した。**GUI付きは4実行とも未完走で、CP-12全体の完了とはしていない。** 加減速を含むコースは3 m、搬送区間は約50 sim秒、さらに把持準備と12 sim秒の整定を要する。ROS 2 Humble／Gazebo Fortressを維持する。仕様書は設計資料として扱い、ユーザーの指定を優先する。1.0 m/sの資格は発行していない。実機は対象外。

## 実行コマンド

```bash
cd ~/ros2_humble_ws
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch cooperative_transport_bringup compliance_speed_trial.launch.py \
  headless:=true \
  forward_distance_m:=3.0 translation_velocity_m_s:=0.1 record_data:=true
```

上記は完走を確認した**画面なし**のコマンド。出力先は起動時に表示され、既定では毎回別のフォルダを作る。進捗は起動待ち→把持→静止保持→ゼロ点補償→搬送→整定と表示する。終了時は両台のarm／base controllerを停止する。

`headless:=false gui_nvidia_offload:=true`へ変更するとGUIを起動し、搬送物を側方から追う。ただし今回のGUI試験では準備または走行中の時計・センサ・計算更新監視で停止した。**画面付きの安定した3 m完走は未確認**であり、下記の失敗記録を参照する。終了時は起動したGUIも終了する。

今回の実行済みargv・環境・終了コードは[final_commands_010.json](final_commands_010.json)、各試験の`command.json`とlaunchログに保存した。資格は3 m／0.1 m/sの直進一点を対象とし、未検証の距離・速度や変更後のsourceでは起動しない。通常の`compliance_contact_transport.launch.py`（1 m／0.005 m/s）は変更していない。

## 実測結果とログ

|試験|結果・根拠|
|---|---|
|画面なし3 m／0.1 m/s|[carry_100_18/result.json](carry_100_18/result.json)：合格。payload定速GT平均0.099993911 m/s、終端腕XY 27.603 µm、台車速度0|
|0.1 m/s定速中のF/T NaN|[target_fault_010_18/result.json](target_fault_010_18/result.json)：合格。両台ゼロ指令まで23.342 wall ms。実arm／base controller inactive、復旧後に自動再開なし、停止後の把持補正なし|
|公開一括起動・画面なし|[public_3m_010_headless/result.json](public_3m_010_headless/result.json)：合格。payload定速GT平均0.100055506 m/s、GT X移動3.002010 m、終端腕XY 10.960 µm、台車速度0 m/s|
|GUI付き4実行|全て未完走。詳細は[public_attempts_010.json](public_attempts_010.json)|
|搬送中の画面|[画像1](public_3m_010_02_moving_1.png)、[画像2](public_3m_010_02_moving_2.png)、[取得コマンドと時刻](public_3m_010_02_render.json)。**後に停止したGUI試験02の画像**であり、完走の証拠には使わない。Gazebo内部Screenshotサービスで取得し、2台・台車・搬送物を目視確認|
|回帰試験|[regression.log](regression.log)：**295 passed in 239.50s**|
|ビルド|[build_force_memory.log](build_force_memory.log)：2 packages finished|
|画面なし資格・終了照合|[qualification_checks.json](qualification_checks.json)、[final_verification_010.json](final_verification_010.json)：画面なしの受入条件成立。元105モデル／YAML保持、元profile復元、現source／証跡hash一致、起動したプロセスの残存ゼロ。GUI完走の資格を意味しない|

3物体の独立GT速度は各`result.json`に保存。[合格3試験の測定値](trial_metrics.json)、[CSV](trial_summary.csv)、[公開画面なし試験の速度・腕偏差・指力・把持補正のグラフ](public_speed_evidence.png)も参照。公開画面なし試験の動作中腕XY最大は0.323268 mm。リーダー目標はencoderによる距離であり、payloadのGT移動と区別する。

公開GUI実行は[全試行記録](public_attempts_010.json)で4回中0回の正常完了。これは同一構成の観測件数であり、統計的な成功率評価ではない。未達の反復安定性を含めて報告する。

公開GUI初回の[public_3m_010/result.json](public_3m_010/result.json)は準備中のセンサ／clock不整合で搬送前に停止した。JointStateがROS時計より約40 ms、指F/Tが約32 ms先行し、既存の許容−20 msを外れた。2回目の[public_3m_010_02/result.json](public_3m_010_02/result.json)は0.1 m/s走行後の減速中に計算更新間隔54.106 msで既存50 ms監視が停止をラッチした（F/T受信経過72.694 ms）。3回目の[public_3m_010_03/result.json](public_3m_010_03/result.json)は加速中のF/T source経過56 sim msが既存50 sim msを超え、両台停止した（受信経過121.889 wall ms）。4回目の[public_3m_010_04/result.json](public_3m_010_04/result.json)は加速中に計算更新経過121.418 ms、F/T受信経過124.608 msで50 ms監視が停止した。安全条件は変更していない。**GUI付きの完走・処理周期の安定は未達**。

## 制御・安全・評価の境界

Followerは自機F/T・arm・base、clockと共有安全信号を使い、leaderの位置・速度・目標・軌道・TF・GTを購読しない。目標の受理はleader 1件、follower 0件であり、各実行の実グラフ監査に合格した。GTとGUIカメラは評価・表示だけに使う。

短時間の誤差はアームが受け、持続力の0.1 Hz成分から局所速度メモリを更新する。自機encoder・腕偏差・仮想要求が静止条件を満たすと保持し、持続偏差で解除する。アーム偏差の積分は使わない。ソフトウェアの仮想ゲインであり、実機質量・定格の推定値ではない。高速用profileだけがこの制御を有効にする。

制御計算は高速用profileだけROS時計でも更新し、鮮度条件内の実測F/Tを次の測定まで保持する。測定stamp／受信wall時刻は変更しない。配分計算の50 ms更新断停止、filtered F/Tの0.05 sim秒／0.15 wall秒、既存rawセンサ監視、荷重・関節限界・時計・共有許可の監視を維持する。出力前に新しい測定を計算へ反映し、停止を自動解除する1周期ゼロの経路を除いた。

元の腕XY 0.5 mm、終端腕XY 0.1 mm／台車10 µm/s／12秒整定、把持力8／26 N・把持喪失0.3 sim秒等の条件は変更していない。これらは既存シミュレーションの試験条件で、実機の安全限界ではない。relayの監視購読だけBest Effortへ変更し、実driver・指令writer・watchdog期限は保持した。

GUIはプロセス単位のNVIDIA offloadを使う。試験用worldの変更はSceneBroadcasterの`state_hertz`と`dynamic_pose_hertz`を20に設定した2点だけ。これらを除いたXML全体、ロボットURDF／controller YAML等の一致を照合し、元world・質量・寸法・接触物理・step・センサ周期を保持する。API設定根拠は[Gazebo Fortressの実装](https://github.com/gazebosim/gz-sim/blob/ign-gazebo6/src/systems/scene_broadcaster/SceneBroadcaster.cc)と[NVIDIA公式資料](https://download.nvidia.com/XFree86/Linux-x86_64/590.48.01/README/primerenderoffload.html)、workspace内の導入済みplugin／サービスの実測による。

## 修正ファイル

workspace相対パスの完全な差分一覧は[modified_source_files.json](modified_source_files.json)、CP-12開始時からの差分は[changes.patch](changes.patch)、最終コードは[final_010_sources/](final_010_sources/)、[hash一覧](final_010_source_hashes.json)。開始前からあったユーザーの変更は取り消していない。

|ファイル（`src/humbleble_ws/`以下は省略）|変更目的|
|---|---|
|amir_compliance_control/amir_compliance_control/recentering.py|局所力による持続速度と静止保持をopt-inで追加|
|amir_compliance_control/amir_compliance_control/whole_body_node.py|配分更新順序、局所F/T／clock更新、静止腕保持、最初の停止理由記録|
|amir_compliance_control/amir_compliance_control/interlock.py|relay入力の監視購読QoS変更|
|amir_compliance_control/launch/whole_body_transport.launch.py|speed_trialだけのソフトウェア制御設定|
|amir_compliance_control/test/test_cp7_safety.py|relay停止・両台停止の検証|
|amir_compliance_control/test/test_local_force_memory.py（追加）|局所応答・保持解除・鮮度・計算停止の検証|
|cooperative_transport_bringup/launch/compliance_speed_trial.launch.py|3 m／0.1 m/s資格照合とGUI一括起動|
|cooperative_transport_bringup/launch/compliance_cp12_display_scene.launch.py（追加）|検証済み生成ファイルを変更せず起動|
|cooperative_transport_bringup/config/compliance_speed_gui.config（追加）|側方表示・追従・内部画像取得|
|tools/amir_cp9_transport_trial.py|実測policy／source、停止理由、表示sceneと準備安定の記録|
|tools/cp12_camera_follow.py（追加）|表示カメラのみ追従|
|tools/cp12_display_scene.py（追加）|表示用コピー作成と物理同等性検証|
|tools/test_cp10_launch.py|資格境界・速度／距離・GUIの24試験|

この監査フォルダ内には試験用`run_trials.py`、`check_profile.py`、`capture_frames.py`、`verify_010_and_qualify.py`、`complete_010.py`／`retry_public_010.py`、`analyze_trials.py`、`finalize_010.py`／`write_report_010.py`、生成scene・証跡・本READMEを追加／更新した。親READMEの進捗も更新した。過去の不合格候補と1.0 m/s開発記録は[開発履歴](README_development_history.md)に保持し、現在の合格証跡とは分けている。

## 検証を再実行するコマンド

```bash
source /opt/ros/humble/setup.bash
source ~/ros2_humble_ws/install/setup.bash
cd ~/ros2_humble_ws
ROS_DOMAIN_ID=94 ROS_LOCALHOST_ONLY=1 OPENBLAS_NUM_THREADS=1 /usr/bin/python3 -m pytest \
  src/humbleble_ws/amir_compliance_control/test \
  tools/test_cp9_launch.py tools/test_cp9_metre.py \
  tools/test_cp9_preparation_handoff.py tools/test_cp10_speed.py tools/test_cp10_launch.py -q
python3 audits/whole_body_compliance_20261019/cp12_speed_release/run_trials.py --suite midspeed --suffix NEW_NORMAL
python3 audits/whole_body_compliance_20261019/cp12_speed_release/run_trials.py --suite target_fault --suffix NEW_FAULT
```

同じ出力先は上書きせず、suffixを新規の文字列に置き換える。最終sourceを変更した場合は既存資格を流用せず、正常・異常・回帰・公開GUI試験を再確認する。資格が参照するログの上書きも起動照合で検出されるため、再検証ログは別名に保存する。

## 未解決TODOと次のCPへ進む条件

- 今回の3 m／0.1 m/s直進は画面なし正常・定速異常停止・295回帰・公開画面なし起動・終了照合を完了。**GUI完走が未達のためCP-12全体の完了とはしない**。次のCPへ進むには、安全条件を保ったGUI正常完走と、停止ログを含めた処理周期の評価が必要。
- 準備中のセンサ／clock順序ずれ、走行中の50 ms計算更新監視／F/T鮮度監視の停止、DDS controller service待ち、起動成功率は未解決。表示負荷と通信・計算の遅延を分けて調査し、再現性を評価する。停止閾値は緩和しない。
- Native contactの後退・横・回転と、手順書CP-8の協調ヨー／中心指定の未整定は未受入。これらの追加時は局所購読境界、接触維持、終端整定、異常時の両台停止をそれぞれ確認する。
- 手順書CP-9の実機移行はユーザー指示により対象外。現在のHumble／Fortressを維持し、Jazzy／Harmonic移行も別の検証が必要。

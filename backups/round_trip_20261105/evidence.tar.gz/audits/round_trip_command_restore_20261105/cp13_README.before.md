# 追加試験CP-13：1 m前進・1 m後退

2026-10-29 JST。ユーザーの「別の実行コマンド」「1 m進んで1 m戻る」に対応する追加段階。実機は対象外。Humble／Fortressを維持する。

最終の分離構成で正常往復、後退中F/T異常停止、GUI付き公開コマンドの往復・終了が合格した。1 m前進・1 m後退の専用入口を使用できる。既存の3 m入口・共通gate・資格ファイルは変更前とbyte一致に戻し、公開入口自身のqualificationが通ることを確認した（existing_entry_restored.json）。

## 動作

1. 既存の接触把持・静止保持・安全gate・局所制御の準備を実行する。
2. リーダーの自機座標で+1 mの相対目標を送る。
3. リーダーの目標完了と12 sim秒の停止・整定を確認する。元のアームXY 0.1 mm、フォロワ台車指令10 µm/sの整定条件を保つ。
4. 同じリーダーへ-1 mの相対目標を送り、同様に停止・整定する。
5. 既存の共有停止を要求し、両台の実arm／base controllerがinactiveになってから終了する。

フォロワへ目標は送らない。両台の制御ノードにはleaderの相手位置・速度・軌道・TF・GTを追加していない。GTは試験側で各区間の符号付き変位と往復後の残差を評価し、目標値や速度指令には使わない。カメラは自由操作の既存設定を使い、固定視点・自動追従は追加しない。

速度上限は0.1 m/s。既存の参照加速度0.005 m/s²を保つため、1 m区間は三角形速度プロファイルとなり、理論ピークは約0.07071 m/s、各区間の計画時間は約28.284 sim秒。1 m区間で0.1 m/sまで到達する動作ではない。後退は180度旋回せず、負の前後速度で行う。

## 専用コマンド

```bash
cd ~/ros2_humble_ws
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch cooperative_transport_bringup compliance_round_trip.launch.py \
  headless:=false gui_nvidia_offload:=true \
  forward_distance_m:=1.0 translation_velocity_m_s:=0.1 record_data:=true
```

記録先は起動ログの`CP-13 output_directory`。`goal_1.json`、`goal_2.json`、`progress.jsonl`、`samples.jsonl`、`result.json`で前進・後退を区別する。同じ出力先を上書きしない。

## 現時点の変更ファイル

- cooperative_transport_bringup/launch/compliance_round_trip.launch.py：既存入口と別の往復入口。資格・距離・速度・分離domain／partitionを検証する。
- tools/amir_round_trip_trial.py：既存試験ハーネスから分けた往復実走。既存の把持準備・安全ノード・制御ノードを使用する。
- tools/round_trip_evidence.py：区間別の独立評価と公開資格の検証。
- tools/test_round_trip.py：符号付き連続目標、前進途中の反転拒否、資格拒否、GUI分離等の試験。
- tools/round_trip_safety_gate.py：往復専用のRobotSafetyGate派生クラス。age／future／skewの整数ns比較だけを補正し、購読・力・関節・把持・共有停止の条件を継承する。
- cooperative_transport_bringup/launch/compliance_round_trip_safety.launch.py：往復専用gateと既存のsupervisor／interlock／auditを接続する。
- tools/test_round_trip_gate.py：既存の実ROSセンサ異常・過荷重・関節限界・再開禁止・所有権等16条件を派生gateへ適用する。
- 共通safety.pyと既存test_shared_safety.pyへの開発中の変更は取り消し、変更前とbyte一致。境界6条件は往復のテストファイルへ移した。
- cooperative_transport_bringup/launch/compliance_round_trip_scene.launch.py：元の表示シーンと同じモデル／物理設定で、既存bringupのevent_startupだけを有効化する。
- この段階のrun_acceptance.py、verify_and_qualify.py、監査記録。

## 保存した初回失敗と修正根拠

`normal_01`は前進中の安全停止で不合格。両台停止と実controller inactiveを確認した。ゲートに記録されたセンサ時刻60.812 sと60.832 sの差は整数で正確に20,000,000 nsだが、浮動小数点では0.020000000000003126 sとなり、既存の`> 0.02`条件に入った。最古sampleのageは4 ms、futureは16 ms、最大wall ageは約56.91 msで、記録された他のfreshness条件は範囲内だった。

根拠は`normal_01_boundary_analysis.json`。`safety_timestamp_fix.patch`は共有gateを修正していた開発途中の差分で、現在の共有sourceには適用されていない。補正は往復専用派生gateへ切り出した。閾値を緩和せずROS時刻の整数表現で比較し、境界ちょうどは許可、1 ns超過は拒否する。過去の約120 ms制御更新断と同一の原因とは断定しない。

## 試験と受入条件

- 最終の分離構成：**65 passed in 21.27 s**（isolated_tests.log）。往復25条件、派生gateの実ROS安全16条件、既存高速入口の24条件。bringupビルド通過（build_isolated.log）。
- 開発途中の共有gate版では320回帰が通過した（regression.log）。最終構成で新しく実行した65件と区別する。最初の回帰では古い資格の読込を試験fixtureに使った1件が失敗し、fixture修正後に320件を通した（regression_initial.logも保存）。
- 正常往復：両区間の符号付きGT・局所整定・leader完了2件・follower目標0件・終了時の両台controller inactive。
- 後退中異常：リーダーは自機x負方向、対向配置のフォロワは自機x正方向になる。各台の指令と自機encoderの符号一致・実走を確認してF/T NaNを注入する。GTでも両台・搬送物の世界での後退を別途評価する。既存400 ms以内の両台ゼロ指令、実controller inactive、入力回復後の自動再開なし、保持補正の再開なしを要求する。
- 全正常／異常の証跡とsource hashが揃ってから往復資格を発行し、新しい公開GUIコマンドを実行する。既存の3 m資格は再発行しない。

### 保存した開発試験

|試験|結果|
|---|---|
|normal_01|不合格。正確な20 msの浮動小数点境界判定で前進中に停止。|
|normal_02|共有gate補正版の正常往復は合格。物体+1.001658 m、-0.999841 m、往復残差X +1.817 mm。最終構成とsourceが異なるため公開資格には使わない。|
|return_fault_01|不合格。準備中に実際の24～28 ms時刻ずれ。異常注入前。取り消し確認時には既に終了しており、ツールから信号は送っていない。|
|return_fault_02|共有gate補正版の後退中NaN試験は合格。両台ゼロ指令まで15.241 ms。最終構成とは別の開発証跡。|
|normal_gui_03|GUIで前進・後退の2目標は完了したが、後退後整定中に24～32 msの時刻ずれで停止。不合格として保持。|
|forward_normal_01|共有gate補正を従来3 mへ適用した開発試験は、把持姿勢の元0.5 mm条件を外れて停止。中断でwrapper終了コードの保存は未完了。resultとログは保存。既存source／資格はその後変更前へ戻した。|

isolated_normal_04は未起動のleader gripper controllerを待って搬送前にtimeoutし、不合格として保存した。後続の専用シーンでは、bringupで既に用意されているイベント駆動のdescription／manager readinessを有効化した。シーン差分がこの起動待ちフラグだけであることはscene_startup_equivalence.jsonに保存した。

最終分離版の正常試験`isolated_normal_05`は合格（267.90 wall秒）。物体GTの符号付き移動は+1.0016555 m、-0.99983235 m、往復後のX残差は+1.82316 mm。アームXY整定は前進後30.301 µm、後退後28.991 µm、フォロワ終端台車指令は両区間0。leader完了2目標・follower受信0目標・両台実arm／base controller inactiveを確認した。

最終分離版の`isolated_return_fault_03`も合格（192.82 wall秒）。後退中の実encoderはleader -0.0152100 m/s、対向配置follower +0.0150085 m/s。最終ゼロ指令まで**16.244 ms**、両台の実arm／base controller inactive、自動再開なし、保持補正の再開なしを確認。独立GTでも異常注入前0.5 sim秒の移動は両台・物体すべて世界の後退方向だった。

`qualification.log`の20照合が通過し、`qualified_round_trip.json`を発行した。最終構成の正常・異常試験だけを使い、開発中の成功を資格へ流用していない。公開GUI試験`public_gui_01`も合格（329.17 wall秒）。物体GTは前進1.001656645 m、後退-0.999771601 m、往復後X残差1.885048 mm。leader完了2件・follower目標0件、両台の実arm／base controller inactive、GUIとlaunchの正常終了を確認した。生ログ末尾は`CP-13 PASSED`、launch終了コード0。

## 再現用の実行コマンド

```bash
source /opt/ros/humble/setup.bash
source ~/ros2_humble_ws/install/setup.bash
cd ~/ros2_humble_ws
ROS_DOMAIN_ID=94 ROS_LOCALHOST_ONLY=1 OPENBLAS_NUM_THREADS=1 /usr/bin/python3 -m pytest -q \
  tools/test_round_trip.py tools/test_round_trip_gate.py tools/test_cp10_launch.py
colcon build --symlink-install --packages-select cooperative_transport_bringup
python3 audits/whole_body_compliance_20261019/cp13_round_trip/run_acceptance.py --name NEW_NORMAL
python3 audits/whole_body_compliance_20261019/cp13_round_trip/run_acceptance.py --name NEW_FAULT --fault nonfinite
```

`NEW_NORMAL`／`NEW_FAULT`は未使用の名前へ置き換える。実際に使用したargv、ROS domain／partition、終了コードは各`*_commands.json`、内側の実行環境は各試験フォルダの`command.json`、生ログは`*_trial.log`／`*_public.log`に保存。資格再検証・再発行は次のコマンド。実走中は実行せず、封印済みsourceや証跡を上書きしない。

```bash
python3 audits/whole_body_compliance_20261019/cp13_round_trip/verify_and_qualify.py \
  --normal isolated_normal_05 --fault isolated_return_fault_03 --write-release
```

GUIの読取専用service列挙（public_gui_services.json）で`/gui/camera/view_control`の存在と`/gui/follow`、`/gui/move_to/pose`の不在を確認した。カメラ操作やロボット指令は送っていない。

## 未解決TODO・次へ進める条件

この1 m往復プロファイルの実走受入と公開GUI実行は完了。次はGUI起動・完走の複数回再現性と、過去に観測した実際の20 ms超のセンサ／clock転送ずれの原因を確認する。共通gateへ補正を展開する場合は、既存3 mの正常・異常受入を改めて行う。過去の間欠的な処理遅延、協調回転の未整定、ハードウェア安全限界の未確認は別の残課題として保つ。今回の境界修正だけで一般的なGUI運転の安定性が解決したとは扱わない。

## 最終ファイル・証跡

修正／追加ファイルの一覧とSHA256は`modified_files.json`、今回の差分は`changes.patch`、最終の読取検証は`verification.json`。共通gate・従来のlaunch・既存資格・モデルは変更前と一致し、親READMEの進捗記録だけを更新した。新しいlaunch3本はinstallからsourceへリンクされ、ビルド反映済み。

公開試験の外側wrapperの環境と内側launchが生成するpartitionは異なる。実際のROSノード／GUIの環境は`public_gui_01/command.json`を参照する。GUIの手動マウス操作やデスクトップ画像の目視確認は実施していない。GUI実起動、自由カメラservice、物体と両台の移動・停止、正常終了をログと独立GTで確認した。

# CP-13 往復コマンドの実行環境復旧（2026-11-05 JST）

対象はGazeboシミュレーション。後から追加された旋回制御と、検証済みの1 m前進・1 m後退を同じworkspaceで使用するための修正。

## 原因と変更

元の起動前チェックは `qualification does not cover current control/launch sources` で停止した。旋回用Pythonモジュールが増え、planar_leader.py、whole_body.py、wrench_preprocessor.py、setup.py、test_wrench_pipeline.pyも過去の資格と異なる。資格のハッシュを書き換えて現在の制御を合格扱いにはしていない。

`.simulation_runtimes/cp13_round_trip/` に、過去の資格に一致するファイルをコピーした。差のある5ファイルは保存済みの監査コピーからSHA256完全一致で回収した。元のqualification関数・通常/異常の証跡・試験ハーネス・制御コードは、この隔離先で元のまま使用する。launchは元と同じsymlink-install方式を使う。

公開launchは隔離環境の検証後、子プロセスのAMENT_PREFIX_PATH/PYTHONPATHを専用installに向ける。制御ソース、実行時準備スクリプト、installed Pythonコードとlaunchの参照先も検証する。通常シェルの環境変数は変更しない。現在の旋回側68ファイルは保存時のハッシュで照合する。

制御更新遅延で停止した2試行を受け、GUIとシミュレーション/制御を異なるCPU群へ分けた。このPCではsysfsの最大周波数と現在許可されたCPU集合を読み、GUIをCPU 16–23、シミュレーション/制御をCPU 0–15へ割り当てる。起動した子プロセスとそのスレッドにだけ適用し、通常シェルのaffinityは変更しない。同じ性能のCPUだけの環境では分割しない。計算資源の配置を変えるもので、simulation timeでの速度・加速度・安全監視条件は変えていない。

主な変更ファイル：

- `src/humbleble_ws/cooperative_transport_bringup/launch/compliance_round_trip.launch.py`：公開コマンドから専用環境を選択。
- `tools/round_trip_runtime.py`：過去資格・専用installの検証、子プロセス環境の設定。
- `tools/test_round_trip_runtime.py`：専用環境の選択、変更検出、非対応の距離・速度・旋回の起動拒否。
- このフォルダの `prepare_runtime.py`：ハッシュ一致のコピーの生成手順。
- `.simulation_runtimes/cp13_round_trip/`：専用source、証跡、build、install。`COLCON_IGNORE`を置き、通常のworkspaceビルドと分ける。

## 実行コマンド

```bash
cd ~/ros2_humble_ws
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch cooperative_transport_bringup compliance_round_trip.launch.py \
  headless:=false gui_nvidia_offload:=true \
  forward_distance_m:=1.0 \
  translation_velocity_m_s:=0.1 record_data:=true
```

接触把持準備 → 1 m前進 → 停止・整定 → 1 m後退 → 停止。カメラ自由操作。目標はleaderだけに送り、followerは自分のセンサ状態のみを使う。速度設定0.1 m/sは上限で、既存の加速度0.005 m/s²では各1 m区間の計画ピークは約0.071 m/sとなる。

記録は元のworkspaceの `audits/whole_body_compliance_20261019/cp13_round_trip/launch_<日時>/`。起動ログの `CP-13 output_directory` が実際の保存先。各実行で別フォルダを作り、過去ログは上書きしない。

## ビルド・検証ログ

- `build_runtime.log`：専用2 packagesの初回ビルド。
- `build_runtime_symlink.log`：専用bringupを元と同じリンク方式で再ビルド。
- `build_public.log`：通常workspaceのbringupビルド。
- `isolation_tests.log`：専用環境の選択・拒否条件10件。URDFが絶対パスで参照する共有controller YAMLの変更検出、実子プロセスのCPU割当・親への影響なしも含む。
- `archived_regression.log`：検証済みsourceで既存65件、21.18秒で合格。実ROS安全gateの16条件を含む。
- `recovery.json`：コピー元、runtimeのハッシュ、現在の旋回側ファイルの保存時ハッシュ。
- `installed_runtime.json`：専用installのファイルハッシュ。
- `public_gui_01.log`：初回確認で準備スクリプトのコピー漏れを検出。搬送開始前に終了。
- `public_gui_02.log`：把持準備後、コピーinstallのlaunchから安全監視スクリプトを参照できず停止。専用bringupのsymlink-installで修正。
- `public_gui_03.log`：前進と整定は完了したが、後退準備時にwhole-body allocation watchdogが作動。実測allocation age 57.752 ms（元の条件50 ms）、force age 70.955 ms。両台の実arm/base controller inactiveを確認。安全閾値を変えず、失敗ログを保持する。
- `public_gui_04.log`：前進中に同じwatchdogが作動。allocation age 62.845 ms、force age 66.737 ms。両台の実arm/base controller inactiveを確認。CPU配置の変更前の失敗として保持する。

`public_gui_05.log` は上記と同じ公開コマンドで正常終了した。終了コード0、285.14 wall秒。payloadの独立GTは前進 +1.001531750 m、後退 -0.999831412 m。leader完了2目標、follower受信0目標、両台の実arm/base controller inactiveを確認した。`verification.json` の14項目が合格。既存65件と追加10件、計75件の試験も通過した。GUI/制御プロセスが実際に別CPU群で動いた記録は `live_runtime_affinity.json`。

この実行の生データ保存先：

```text
/home/dars5070/ros2_humble_ws/audits/whole_body_compliance_20261019/cp13_round_trip/launch_20261105_023531_518398/
```

再照合コマンド（シミュレーション終了後に実行）：

```bash
source /opt/ros/humble/setup.bash
source ~/ros2_humble_ws/install/setup.bash
cd ~/ros2_humble_ws
/usr/bin/python3 audits/round_trip_command_restore_20261105/verify_result.py --run public_gui_05
```

## 未解決TODO・次へ進む条件

過去に観測された20 ms超の実際のセンサ時刻ずれなど、GUI実行の間欠的な安全停止の原因調査は継続する。閾値の緩和はしない。実機や1.0 m/sの認定には使用しない。専用環境で制御コード・モデル・閾値を変更する場合は、正常往復と後退中異常停止の証跡を取り直す。

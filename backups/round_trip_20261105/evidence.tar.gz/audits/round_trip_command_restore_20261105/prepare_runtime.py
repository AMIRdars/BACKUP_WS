"""Recover the qualified CP-13 runtime without replacing newer rotation work."""
from pathlib import Path
import hashlib
import json
import shutil


ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / '.simulation_runtimes/cp13_round_trip'
CP = Path('audits/whole_body_compliance_20261019')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if DEST.exists():
        raise ValueError('Preserve existing runtime: ' + str(DEST))
    manifests = [CP/'cp12_speed_release/qualified_speed_010.json',
                 CP/'cp13_round_trip/qualified_round_trip.json']
    requested = {}
    for relative in manifests:
        manifest = json.loads((ROOT/relative).read_text())
        requested[str(relative)] = sha(ROOT/relative)
        for key in ('source_sha256', 'evidence_sha256'):
            for name, digest in manifest[key].items():
                if name in requested and requested[name] != digest:
                    raise ValueError('Conflicting evidence: ' + name)
                requested[name] = digest
        for trial in ('normal_trial', 'fault_trial'):
            sources = json.loads((ROOT/manifest[trial]/'trial_source_hashes.json').read_text())
            for absolute, digest in sources.items():
                relative_source = str(Path(absolute).relative_to(ROOT))
                if relative_source in requested and requested[relative_source] != digest:
                    raise ValueError('Conflicting runtime source: '+relative_source)
                requested[relative_source] = digest
    recovered = {}
    for name, digest in requested.items():
        source = ROOT/name
        if not source.is_file() or sha(source) != digest:
            # These are stored, byte-identical sources, never a reconstructed guess.
            candidates = (ROOT/'audits').rglob(Path(name).name+'*')
            source = next((p for p in candidates if p.is_file()
                           and p.stat().st_size < 200000 and sha(p) == digest), None)
            if source is None:
                raise ValueError('No byte-identical source for ' + name)
            recovered[name] = str(source.relative_to(ROOT))
        target = DEST/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    # Additional inputs used by the unchanged commissioning/evaluation harness.
    extras = [
        'tools/amir_make_safety_profiles.py',
        'src/humbleble_ws/amir_compliance_control/setup.cfg',
        'src/humbleble_ws/amir_compliance_control/resource/amir_compliance_control',
        'src/humbleble_ws/amir_compliance_control/README.md',
        'src/humbleble_ws/cooperative_transport_bringup/CMakeLists.txt',
        'src/humbleble_ws/cooperative_transport_bringup/package.xml',
        str(CP/'cp1/motion_run3/motion.json'),
        str(CP/'cp9_transport/metrology_02/generated_hashes.json'),
        str(CP/'cp9_transport/metrology_02/static_proof/runtime.json'),
        str(CP/'cp12_speed_release/generated_gui20/leader_safety.json'),
        str(CP/'cp12_speed_release/generated_gui20/follower_safety.json'),
    ]
    for name in extras:
        target = DEST/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT/name, target)
        requested[name] = sha(target)
    (DEST/'COLCON_IGNORE').touch()
    # Snapshot newer sources so preservation can be verified after the live run.
    current = ROOT/'src/humbleble_ws/amir_compliance_control'
    preserved = {str(p.relative_to(ROOT)): sha(p) for p in current.rglob('*')
                 if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
    record = {'runtime': str(DEST), 'recovered_sources': recovered,
              'runtime_sha256': requested, 'preserved_current_control_sha256': preserved}
    (Path(__file__).parent/'recovery.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps({'runtime': str(DEST), 'files': len(requested),
                      'recovered_sources': recovered}, indent=2))


if __name__ == '__main__':
    main()

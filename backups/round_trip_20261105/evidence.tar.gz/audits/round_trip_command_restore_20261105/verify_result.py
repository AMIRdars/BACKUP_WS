"""Read-only postflight checks for a completed public command (no qualification rewrite)."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT/'tools'))
from round_trip_runtime import validate


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', default='public_gui_05')
    args = parser.parse_args()
    log = (HERE/(args.run+'.log')).read_text()
    command = json.loads((HERE/(args.run+'_command.json')).read_text())
    output = Path(re.search(r'CP-13 output_directory: (.+)', log)[1].strip())
    result = json.loads((output/'result.json').read_text())
    entry, runtime = validate(ROOT)
    spec = importlib.util.spec_from_file_location('sealed_cp13_metrics',runtime/'tools/round_trip_evidence.py')
    metrics = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metrics)
    recovery = json.loads((HERE/'recovery.json').read_text())
    control = runtime/'src/humbleble_ws/amir_compliance_control/amir_compliance_control'
    expected = {p.name:sha(p) for p in control.glob('*.py')}
    checks = {
        'qualified_archive_and_install': True,
        'exact_public_command_exited_zero': command['returncode'] == 0,
        'normal_round_trip_acceptance': metrics.normal_passed(result),
        'both_actual_arm_base_inactive': result.get('both_arm_base_inactive') is True,
        'follower_local_input_boundary': result.get('follower_input_boundary_passed') is True,
        'runtime_controller_sources_equal_qualified_archive': json.loads((output/'control_source_hashes.json').read_text()) == expected,
        'temporary_safety_profiles_restored': all(json.loads((output/'original_profiles_restored.json').read_text()).values()),
        'newer_control_sources_preserved': all((ROOT/p).is_file() and sha(ROOT/p) == digest
            for p,digest in recovery['preserved_current_control_sha256'].items()),
        'gui_started_and_exited_cleanly': bool(re.search(r'\[cp13_gazebo_gui-1\]: process started',log))
            and bool(re.search(r'\[cp13_gazebo_gui-1\]: process has finished cleanly',log)),
        'success_message': 'CP-13 PASSED' in log,
        'isolation_tests_passed': '10 passed' in (HERE/'isolation_tests.log').read_text(),
        'qualified_regression_passed': '65 passed' in (HERE/'archived_regression.log').read_text(),
        'public_entry_installed': (ROOT/'install/cooperative_transport_bringup/share/cooperative_transport_bringup/launch/compliance_round_trip.launch.py').resolve() == ROOT/'src/humbleble_ws/cooperative_transport_bringup/launch/compliance_round_trip.launch.py',
    }
    # Confirm the two process IDs owned by the public launch have exited.
    owned = [int(v) for v in re.findall(r'process started with pid \[(\d+)\]',log)]
    checks['public_launch_children_exited'] = all(not Path(f'/proc/{pid}').exists() for pid in owned)
    report = {'passed': all(checks.values()), 'checks': checks,
              'output_directory': str(output), 'public_command': command,
              'payload_displacement_m': [leg['bodies']['cooperative_payload']['signed_displacement_m']
                                         for leg in result.get('legs',[])],
              'preserved_newer_control_files': len(recovery['preserved_current_control_sha256']),
              'runtime_files': len(recovery['runtime_sha256']),
              'unchanged_safety_thresholds': True,
              'universal_gui_reliability_established': False}
    (HERE/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    if not report['passed']:
        raise RuntimeError('Postflight failed; preserve the trial and inspect verification.json')


if __name__ == '__main__':
    main()

"""Launch the qualified contact round trip alongside newer rotation development."""
import importlib.util
from pathlib import Path

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction


def workspace():
    for root in Path(__file__).resolve().parents:
        if (root/'tools/round_trip_runtime.py').is_file():
            return str(root)
    raise ValueError('Workspace containing tools/round_trip_runtime.py not found')


def setup(context):
    root = Path(context.launch_configurations['workspace_directory']).expanduser().resolve()
    path = root/'tools/round_trip_runtime.py'
    spec = importlib.util.spec_from_file_location('cp13_runtime', path)
    runtime = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runtime)
    return runtime.setup(context)


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('workspace_directory', default_value=workspace()),
        DeclareLaunchArgument('headless', default_value='false', choices=['true', 'false']),
        DeclareLaunchArgument('gui_nvidia_offload', default_value='true', choices=['true', 'false']),
        DeclareLaunchArgument('forward_distance_m', default_value='1.0'),
        DeclareLaunchArgument('translation_velocity_m_s', default_value='0.1'),
        DeclareLaunchArgument('record_data', default_value='true', choices=['true']),
        DeclareLaunchArgument('output_directory', default_value=''),
        DeclareLaunchArgument('ros_domain_id', default_value='93'),
        OpaqueFunction(function=setup)])

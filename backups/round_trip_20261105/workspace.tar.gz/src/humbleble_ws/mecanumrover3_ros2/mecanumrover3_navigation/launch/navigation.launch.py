# Copyright 2019 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Author: Darby Lim

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch.conditions import IfCondition, LaunchConfigurationEquals


def generate_launch_description():
    nav2_launch_file_dir = os.path.join(
        get_package_share_directory('mecanumrover3_navigation'), 'launch')
        
    use_sim_time = LaunchConfiguration('use_sim_time', default='false')
    map_dir = LaunchConfiguration(
        'map',
        default=os.path.join(
            get_package_share_directory('mecanumrover3_navigation'),
            'maps',
            'test.yaml'))  # change this to your own map for navigation

    mecanum3_param_dir = LaunchConfiguration(
        'params_file',
        default=os.path.join(
            get_package_share_directory('mecanumrover3_navigation'),
            'config',
            'mecanum3_nav2_params.yaml'))

    g120a_param_dir = LaunchConfiguration(
        'params_file',
        default=os.path.join(
            get_package_share_directory('mecanumrover3_navigation'),
            'config',
            'g120a_nav2_params.yaml'))
            
    g40a_lb_param_dir = LaunchConfiguration(
        'params_file',
        default=os.path.join(
            get_package_share_directory('mecanumrover3_navigation'),
            'config',
            'g40a_lb_nav2_params.yaml'))
            
    rviz_config_dir = os.path.join(
        get_package_share_directory('mecanumrover3_navigation'),
        'rviz',
        'nav2.rviz')

    return LaunchDescription([
        DeclareLaunchArgument(
            'rover',
            default_value='mecanum3',
            description='mecanum3 model',
            choices=['mecanum3', 'g120a', 'g40a_lb']),
            
        DeclareLaunchArgument(
            'map',
            default_value=map_dir,
            description='Full path to map file to load'),

        DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='Use simulation (Gazebo) clock if true'),
            
        DeclareLaunchArgument(
            'params_file',
            condition=LaunchConfigurationEquals('rover', 'mecanum3'),
            default_value=mecanum3_param_dir,
            description='Full path to param file to load'),
            
        DeclareLaunchArgument(
            'params_file',
            condition=LaunchConfigurationEquals('rover', 'g120a'),
            default_value=g120a_param_dir,
            description='Full path to param file to load'),
            
        DeclareLaunchArgument(
            'params_file',
            condition=LaunchConfigurationEquals('rover', 'g40a_lb'),
            default_value=g40a_lb_param_dir,
            description='Full path to param file to load'),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                [nav2_launch_file_dir, '/bringup_launch.py']),
            condition=LaunchConfigurationEquals('rover', 'mecanum3'),
            launch_arguments={
                'map': map_dir,
                'use_sim_time': use_sim_time,
                'params_file': mecanum3_param_dir}.items(),
        ),
        
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                [nav2_launch_file_dir, '/bringup_launch.py']),
            condition=LaunchConfigurationEquals('rover', 'g120a'),
            launch_arguments={
                'map': map_dir,
                'use_sim_time': use_sim_time,
                'params_file': g120a_param_dir}.items(),
        ),
        
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                [nav2_launch_file_dir, '/bringup_launch.py']),
            condition=LaunchConfigurationEquals('rover', 'g40a_lb'),
            launch_arguments={
                'map': map_dir,
                'use_sim_time': use_sim_time,
                'params_file': g40a_lb_param_dir}.items(),
        ),

        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', rviz_config_dir],
            parameters=[{'use_sim_time': use_sim_time}],
            output='screen'),
    ])


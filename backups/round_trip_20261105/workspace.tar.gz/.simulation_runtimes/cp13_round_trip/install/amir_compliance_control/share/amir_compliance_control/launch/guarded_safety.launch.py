"""CP-7 final output ownership and independent controller deactivation path."""
from pathlib import Path
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def setup(context):
    folder=Path(LaunchConfiguration('run_directory').perform(context)).resolve()
    actions=[Node(package='amir_compliance_control',executable='safety_supervisor',
        parameters=[{'use_sim_time':True,'require_interlocks':True}],additional_env={'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'},output='screen')]
    for robot in ('leader','follower'):
        actions += [Node(package='amir_compliance_control',executable='safety_gate',namespace=robot,
            parameters=[{'use_sim_time':True,'urdf_file':str(folder/(robot+'.urdf')),
                         'profile_file':str(folder/(robot+'_safety.json'))}],
            remappings=[('rover_twist','interlock/base_request'),
                        ('arm_controller/joint_trajectory','interlock/arm_request')],additional_env={'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'},output='screen'),
            Node(package='amir_compliance_control',executable='actuator_interlock',namespace=robot,
                 parameters=[{'use_sim_time':True,'urdf_file':str(folder/(robot+'.urdf')),
                              'profile_file':str(folder/(robot+'_safety.json'))}],additional_env={'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'},output='screen'),
            Node(package='amir_compliance_control',executable='controller_audit',namespace=robot,additional_env={'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'},output='screen')]
    return actions


def generate_launch_description():
    return LaunchDescription([DeclareLaunchArgument('run_directory'),OpaqueFunction(function=setup)])

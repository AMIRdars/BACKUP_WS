"""One isolated CP-13 simulation, retaining success and failure logs."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import uuid


STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--name',required=True)
    parser.add_argument('--fault',choices=['none','nonfinite'],default='none')
    parser.add_argument('--gui',action='store_true')
    parser.add_argument('--public',action='store_true')
    parser.add_argument('--profile',choices=['round_trip','forward'],default='round_trip',
        help='Recheck the existing 3 m straight entry after the exact-time fix')
    args=parser.parse_args()
    if args.public and args.fault!='none':
        raise ValueError('public entry never injects faults')
    if args.public and args.profile!='round_trip':
        raise ValueError('public acceptance here is for the new round-trip entry')
    output=STAGE/args.name
    if output.exists() or (STAGE/(args.name+'_commands.json')).exists():
        raise ValueError('preserve existing trial: '+str(output))
    env=dict(os.environ,ROS_DOMAIN_ID='94',ROS_LOCALHOST_ONLY='1',
        IGN_PARTITION='amir_cp9_round_trip_'+uuid.uuid4().hex[:12],
        RMW_FASTRTPS_PUBLICATION_MODE='ASYNCHRONOUS',OPENBLAS_NUM_THREADS='1',
        OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONUNBUFFERED='1')
    if args.public:
        argv=['ros2','launch','cooperative_transport_bringup','compliance_round_trip.launch.py',
            'headless:='+str(not args.gui).lower(),'gui_nvidia_offload:=true',
            'output_directory:='+str(output),'ros_domain_id:=94']
    else:
        argv=['/usr/bin/python3',str(ROOT/'tools/amir_round_trip_trial.py'),
            '--run-directory',str(STAGE.parent/'cp12_speed_release/generated_gui20'),
            '--metrology-directory',str(STAGE.parent/'cp9_transport/metrology_02'),
            '--output',str(output),'--distance','1.0','--speed','0.1',
            '--base-speed-evidence',str(STAGE.parent/'cp10_speed_1ms/base_03'),
            '--fault',args.fault]
        if args.profile=='forward':
            argv[1]=str(ROOT/'tools/amir_cp9_transport_trial.py')
            argv[argv.index('--distance')+1]='3.0'
            argv.extend(['--experimental-speed-profile','--grip-maintenance','--display-scene'])
            if args.fault!='none':
                argv.append('--fault-at-cruise')
    processes=[]; logs=[]; started=time.monotonic()
    def start(role,cmd,run_env):
        log=(STAGE/(args.name+'_'+role+'.log')).open('w');logs.append(log)
        process=subprocess.Popen(cmd,cwd=ROOT,env=run_env,stdout=log,
            stderr=subprocess.STDOUT,start_new_session=True)
        processes.append((role,process,cmd));return process
    try:
        if args.gui and not args.public:
            gui_env=dict(env,__NV_PRIME_RENDER_OFFLOAD='1',__GLX_VENDOR_LIBRARY_NAME='nvidia')
            start('gui',['ign','gazebo','-g','--gui-config',
                str(ROOT/'src/humbleble_ws/cooperative_transport_bringup/config/compliance_speed_gui.config'),
                '--force-version','6'],gui_env)
        process=start('public' if args.public else 'trial',argv,env)
        deadline=time.monotonic()+900.
        while process.poll() is None and time.monotonic()<deadline:
            time.sleep(.2)
        if process.poll() is None:
            raise TimeoutError('preserved CP-13 timeout')
    finally:
        for _,process,_ in reversed(processes):
            if process.poll() is None:
                os.killpg(process.pid,signal.SIGINT)
                try:process.wait(timeout=120.)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid,signal.SIGTERM);process.wait(timeout=15.)
        for log in logs:log.close()
        result=json.loads((output/'result.json').read_text()) if (output/'result.json').exists() else {}
        record={'processes':[{'role':role,'argv':cmd,'returncode':p.returncode} for role,p,cmd in processes],
            'environment':{k:env[k] for k in ('ROS_DOMAIN_ID','ROS_LOCALHOST_ONLY','IGN_PARTITION','RMW_FASTRTPS_PUBLICATION_MODE')},
            'wall_s':time.monotonic()-started,'passed':result.get('passed',False),
            'error':result.get('error'),'error_phase':result.get('error_phase')}
        (STAGE/(args.name+'_commands.json')).write_text(json.dumps(record,indent=2)+'\n')
        print(json.dumps(record,indent=2),flush=True)
    if not record['passed'] or any(p.returncode!=0 for _,p,_ in processes):
        raise RuntimeError('preserve failure and diagnose: '+args.name)


if __name__=='__main__':
    main()

"""Qualify the isolated CP-13 route without modifying existing CP-12 proof.

Read-only except for this stage's acceptance report and optional manifest.
Every control limit and old source/evidence byte must remain unchanged.
"""
import argparse
import ast
import importlib.util
import json
import math
import os
from pathlib import Path
import sys

STAGE=Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
sys.path.insert(0,str(ROOT/'tools'))
from round_trip_evidence import SOURCES, normal_passed, fault_passed, sha, qualification
PARENT=Path('audits/whole_body_compliance_20261019/cp12_speed_release/qualified_speed_010.json')
SPEC=importlib.util.spec_from_file_location('cp13_parent',ROOT/
    'src/humbleble_ws/cooperative_transport_bringup/launch/compliance_speed_trial.launch.py')
parent=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(parent)


def read(path):return json.loads(Path(path).read_text())


def runtime_evidence(folder):
    names=['result.json','control_source_hashes.json','trial_source_hashes.json','control_policy.json',
        'leader_policy.json','original_profiles_restored.json','command.json','graph.json',
        'profiles_used/leader_safety.json','profiles_used/follower_safety.json']
    names.extend(p.name for p in folder.glob('goal*.json'))
    if (folder/'post_fault_controller_snapshot.json').exists():names.append('post_fault_controller_snapshot.json')
    return {str((folder/name).relative_to(ROOT)):sha(folder/name) for name in names}


def idle():
    partitions={read(p)['IGN_PARTITION'] for p in STAGE.glob('*/command.json')}
    left=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name)==os.getpid():continue
        try:
            env=(p/'environ').read_bytes().split(b'\0')
            if any(('IGN_PARTITION='+s).encode() in env for s in partitions):left.append(int(p.name))
        except OSError:pass
    return left


def precise_change_only():
    original=ast.parse((ROOT/'src/humbleble_ws/amir_compliance_control/amir_compliance_control/safety.py').read_text())
    wrapper=ast.parse((ROOT/'tools/round_trip_safety_gate.py').read_text())
    def health(tree,classname):
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==classname)
        method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='healthy')
        method.body=[n for n in method.body if not (
            isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in
                ('stamps','max_age_ns','max_skew_ns') for t in n.targets)) and not (
            isinstance(n,ast.If) and any(isinstance(c,ast.Constant) and
                c.value=='local sensors stale, future or skewed' for c in ast.walk(n)))]
        return ast.dump(method)
    return health(original,'RobotSafetyGate')==health(wrapper,'PreciseSafetyGate')


def return_gt_direction(folder):
    moving=[json.loads(line) for line in (folder/'samples.jsonl').open()]
    moving=[r for r in moving if r.get('leg')==2 and r['phase']=='motion']
    if not moving:return {}
    recent=[r for r in moving if r['sim_time']>=moving[-1]['sim_time']-.5]
    first,last=recent[0],recent[-1];yaw=first['leader_gt_yaw']
    return {body:math.cos(yaw)*(last[prefix+'x']-first[prefix+'x'])+
        math.sin(yaw)*(last[prefix+'y']-first[prefix+'y']) for body,prefix in
        (('leader','leader_gt_'),('follower','follower_gt_'),('cooperative_payload','payload_'))}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--normal',required=True)
    parser.add_argument('--fault',required=True)
    parser.add_argument('--write-release',action='store_true')
    args=parser.parse_args()
    folders=[(STAGE/n).resolve() for n in (args.normal,args.fault)]
    if any(f.parent!=STAGE for f in folders):raise ValueError('select trials within this stage')
    inherited=parent.qualification(ROOT)
    baseline=read(STAGE/'before'/(str(PARENT)+'.before'))
    saved=read(STAGE/'before/source_hashes.json')
    preserved={n:sha(ROOT/n)==v for n,v in saved.items() if n!='audits/whole_body_compliance_20261019/README.md'}
    current={p.name:sha(p) for p in (ROOT/'src/humbleble_ws/amir_compliance_control/amir_compliance_control').glob('*.py')}
    normal,fault=(read(f/'result.json') for f in folders)
    gt_direction=return_gt_direction(folders[1])
    tests=(STAGE/'isolated_tests.log').read_text()
    checks={
        'all_previous_sources_models_evidence_preserved':all(preserved.values()),
        'existing_parent_qualification_identical':sha(ROOT/PARENT)==sha(STAGE/'before'/(str(PARENT)+'.before')),
        'inherited_safety_checks_except_timestamp_arithmetic_identical':precise_change_only(),
        'isolated_gate_route_and_original_launch_tests':'65 passed' in tests and 'failed' not in tests,
        'build_passed':'1 package finished' in (STAGE/'build_event_startup.log').read_text(),
        'scene_differs_only_by_event_driven_startup':read(STAGE/'scene_startup_equivalence.json').get(
            'same_scene_launch_except_existing_event_startup_flag') is True,
        'no_owned_processes':not idle(),
        'current_control_sources_unchanged':all(read(f/'control_source_hashes.json')==current for f in folders),
        'current_runtime_trial_sources':all(all(sha(n)==v for n,v in read(f/'trial_source_hashes.json').items()) for f in folders),
        'same_follower_policy':all(read(f/'control_policy.json')==read(ROOT/baseline['normal_trial']/'control_policy.json') for f in folders),
        'same_leader_acceleration_tolerance_timeout':all(all(read(f/'leader_policy.json')[k]==v
            for k,v in read(ROOT/baseline['normal_trial']/'leader_policy.json').items()
            if k!='max_distance_m') for f in folders),
        'profiles_restored':all(read(f/'original_profiles_restored.json')=={'leader':True,'follower':True} for f in folders),
        'native_grasp_simulation_only':all(read(f/'result.json').get('native_contact_only') is True
            and read(f/'result.json').get('hardware_motion_gate_open') is False
            and read(f/'result.json').get('grip_maintenance_enabled') is True for f in folders),
        'all_final_controllers_inactive':all(read(f/'result.json').get('both_arm_base_inactive') is True for f in folders),
        'follower_local_input_boundaries':all(read(f/'result.json').get('follower_input_boundary_passed') is True for f in folders),
        'asynchronous_local_only':all(read(f/'command.json').get('RMW_FASTRTPS_PUBLICATION_MODE')=='ASYNCHRONOUS'
            and read(f/'command.json').get('ROS_LOCALHOST_ONLY')=='1' for f in folders),
        'normal_round_trip_passed':normal_passed(normal),
        'return_fault_passed':fault_passed(fault),
        'return_all_three_gt_moving_backward':set(gt_direction)=={'leader','follower','cooperative_payload'}
            and all(v < -1e-6 for v in gt_direction.values()),
        'goals_exactly_plus_then_minus':all(read(f/'goal_1.json')['relative_xy_yaw']==[1.,0.,0.]
            and read(f/'goal_2.json')['relative_xy_yaw']==[-1.,0.,0.] for f in folders),
    }
    report={'passed':all(checks.values()),'checks':checks,
        'normal_trial':str(folders[0].relative_to(ROOT)),'fault_trial':str(folders[1].relative_to(ROOT)),
        'independent_return_gt_travel_before_fault_m':gt_direction,
        'scope':'isolated simulation route; no universal GUI stability or hardware acceptance'}
    report_path=STAGE/'round_trip_acceptance.json';report_path.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    if not report['passed']:return 1
    evidence={str(p.relative_to(ROOT)):sha(p) for p in
        (report_path,STAGE/'isolated_tests.log',STAGE/'build_event_startup.log',
         STAGE/'scene_startup_equivalence.json',STAGE/'normal_01_boundary_analysis.json')}
    for folder in folders:evidence.update(runtime_evidence(folder))
    paths=list(SOURCES)+[str(Path(__file__).relative_to(ROOT)),str((STAGE/'run_acceptance.py').relative_to(ROOT))]
    m={'schema_version':1,'passed':True,'simulation_only':True,'distance_m':1.,'speed_m_s':.1,
        'normal_trial':report['normal_trial'],'fault_trial':report['fault_trial'],
        'parent_qualification_sha256':sha(ROOT/PARENT),
        'source_sha256':{n:sha(ROOT/n) for n in paths},'evidence_sha256':evidence}
    if args.write_release:
        destination=STAGE/'qualified_round_trip.json'
        previous=destination.read_bytes() if destination.exists() else None
        destination.write_text(json.dumps(m,indent=2)+'\n')
        try:qualification(ROOT,inherited)
        except Exception:
            if previous is None:destination.unlink()
            else:destination.write_bytes(previous)
            raise
        print('Release accepted by actual launch qualification: '+str(destination))
    return 0


if __name__=='__main__':raise SystemExit(main())

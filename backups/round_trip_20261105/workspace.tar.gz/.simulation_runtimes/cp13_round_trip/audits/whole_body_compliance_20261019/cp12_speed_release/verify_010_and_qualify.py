"""Recheck saved Gazebo evidence; release only the measured 3 m / 0.1 m/s case.

This reads files and /proc only. It never creates ROS nodes or sends motion.
--write-release is effective only when every required acceptance check passes.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import xml.etree.ElementTree as ET

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
CONTROL = ROOT/'src/humbleble_ws/amir_compliance_control/amir_compliance_control'
BASE = STAGE.parent/'cp10_speed_1ms/base_03'
PRIOR = STAGE.parent/'cp9_transport'
DISPLAY_SCENE = STAGE/'generated_gui20'


def read(p):
    return json.loads(p.read_text())


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def no_owned_processes():
    partitions = {read(p)['IGN_PARTITION'] for p in STAGE.glob('*/command.json')}
    remaining = []
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            env = (p/'environ').read_bytes().split(b'\0')
            if any(('IGN_PARTITION='+s).encode() in env for s in partitions):
                remaining.append({'pid': int(p.name),
                    'command': (p/'cmdline').read_bytes().replace(b'\0',b' ').decode()})
        except OSError:
            pass
    (STAGE/'remaining_owned_processes.json').write_text(json.dumps(remaining, indent=2))
    return not remaining


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--normal', default='carry_100_18')
    p.add_argument('--fault', default='target_fault_010_18')
    p.add_argument('--write-release', action='store_true')
    args = p.parse_args()
    normal, fault = STAGE/args.normal, STAGE/args.fault
    missing = [str(path) for path in (normal/'result.json', fault/'result.json',
        STAGE/'regression.log') if not path.is_file()]
    if missing:
        print('Qualification incomplete; missing: '+', '.join(missing))
        return 2
    n, f, b = read(normal/'result.json'), read(fault/'result.json'), read(BASE/'result.json')
    current = {p.name:sha(p) for p in CONTROL.glob('*.py')}
    before = read(STAGE/'before/source_hashes.json')
    preserved = {path:sha(ROOT/path) == digest for path,digest in before.items()
                 if '/amir_compliance_control/' in path and not path.endswith((
                     '/launch/whole_body_transport.launch.py', '/amir_compliance_control/recentering.py',
                     '/amir_compliance_control/whole_body_node.py', '/amir_compliance_control/interlock.py',
                     '/test/test_cp7_safety.py'))}
    (STAGE/'prior_control_package_preserved.json').write_text(json.dumps(preserved, indent=2))
    originals = read(PRIOR/'before/source_hashes.json')
    models = {path:sha(ROOT/path) == digest for path,digest in originals.items()
              if path.endswith(('.urdf','.xacro','.sdf','.yaml','.yml'))}
    (STAGE/'original_models_preserved.json').write_text(json.dumps(models, indent=2))
    regression = (STAGE/'regression.log').read_text()
    counts = re.findall(r'(\d+) passed', regression)
    count = int(counts[-1]) if counts else 0
    policies_equal = all(read(normal/name) == read(fault/name)
        for name in ('control_policy.json','leader_policy.json'))
    maintenance_fault_ok = all(
        f.get('maintenance_after_fault_recovery',{}).get(r,{}).get('state') == 'FAULT'
        and 'sent_goals' in f.get('maintenance_at_dual_stop',{}).get(r,{})
        and f['maintenance_at_dual_stop'][r]['sent_goals'] == f['maintenance_after_fault_recovery'][r]['sent_goals']
        for r in ('leader','follower'))
    tracks = n.get('independent_speed_evaluation',{})
    latency = f.get('dual_zero_latency_wall_s',math.inf)
    original_world=ET.parse(PRIOR/'generated/world.sdf').getroot()
    display_world=ET.parse(DISPLAY_SCENE/'world.sdf').getroot()
    display_plugin=display_world.find("world/plugin[@name='ignition::gazebo::systems::SceneBroadcaster']")
    display_settings={c.tag:c.text for c in display_plugin}
    for child in list(display_plugin):display_plugin.remove(child)
    display_only=(display_settings=={'state_hertz':'20','dynamic_pose_hertz':'20'}
        and ET.tostring(display_world)==ET.tostring(original_world))
    checks = {
        'ungrasped_base_28_cases': b['passed'] and len(read(BASE/'motion.json')) == 28,
        'normal_3m_010_native_carry_completed': n.get('passed') is True
            and n.get('cooperative_contact_transport_verified') is True
            and n.get('distance_m') == 3. and n.get('speed_m_s') == .1,
        'independent_gt_all_three_bodies_at_010': set(tracks) == {'leader','follower','cooperative_payload'}
            and all(.098 <= v.get('steady_gt_mean_m_s',0.) <= .102 for v in tracks.values()),
        'normal_arm_settled_original_limit': 0 <= n.get('final_arm_offset_xy_m', math.inf) <= .0001,
        'normal_base_stopped_original_limit': 0 <= n.get('final_follower_speed_m_s', math.inf) <= .00001,
        'nonfinite_fault_passed': f.get('passed') is True and f.get('fault_test') == 'nonfinite'
            and f.get('fault_injected') is True,
        'fault_injected_at_commanded_and_measured_cruise': all(
            abs(f.get('twists_at_injection',{}).get(r,[0.])[0]) >= .0999
            and abs(f.get('measured_encoder_vx_at_injection',{}).get(r,0.)) >= .0999
            for r in ('leader','follower')),
        'actual_both_bases_travelled_before_fault': min(f.get('gt_travel_before_injection_m',{'none':0.}).values()) > 1e-6,
        'dual_zero_within_existing_400ms': math.isfinite(latency) and 0 <= latency <= .4,
        'fault_actual_controllers_inactive_before_cleanup': all(
            f.get('post_fault_controller_states',{}).get(r,{}).get(c) == 'inactive'
            for r in ('leader','follower') for c in ('arm_controller','mecanum_drive_controller')),
        'fault_no_automatic_restart': f.get('no_automatic_restart') is True,
        'no_grip_commands_after_fault_stop': maintenance_fault_ok,
        'both_trials_grip_maintenance_enabled': all(d.get('grip_maintenance_enabled') is True for d in (n,f)),
        'both_trials_cleanup_controllers_inactive': all(d.get('both_arm_base_inactive') is True for d in (n,f)),
        'both_follower_boundaries_passed': all(d.get('follower_input_boundary_passed') is True for d in (n,f)),
        'follower_accepted_no_goals': all(d.get('endpoint_states',{}).get('follower',{}).get('accepted_goals') == 0 for d in (n,f)),
        'leader_only_goal': all(d.get('endpoint_states',{}).get('leader',{}).get('accepted_goals') == 1 for d in (n,f)),
        'simulation_native_contact_no_hardware': all(d.get('native_contact_only') is True
            and d.get('hardware_motion_gate_open') is False for d in (n,f)),
        'normal_fault_same_current_control_sources': all(read(folder/'control_source_hashes.json') == current for folder in (normal,fault)),
        'normal_fault_current_trial_sources': all(all(sha(Path(path)) == digest
            for path,digest in read(folder/'trial_source_hashes.json').items()) for folder in (normal,fault)),
        'normal_fault_same_policies': policies_equal,
        'own_force_velocity_memory_without_deflection_integral': all(
            read(folder/'control_policy.json').get('base_force_acceleration_gains') == [.05,0.,0.]
            and read(folder/'control_policy.json').get('base_force_filter_hz') == .1
            and read(folder/'control_policy.json').get('base_stationary_hold') is True
            and read(folder/'control_policy.json').get('arm_command_horizon_s') == .02
            and read(folder/'control_policy.json').get('allocation_on_wrench') is True
            and read(folder/'control_policy.json').get('allocation_use_clock') is True
            and read(folder/'control_policy.json').get('base_integral_gains') == [0.,0.,0.]
            for folder in (normal,fault)),
        'both_trials_explicit_async_mode': all(read(folder/'command.json').get('RMW_FASTRTPS_PUBLICATION_MODE') == 'ASYNCHRONOUS'
            for folder in (normal,fault)),
        'both_trials_profiles_restored': all(all(read(folder/'original_profiles_restored.json').values()) for folder in (normal,fault)),
        'other_control_and_safety_sources_preserved': all(preserved.values()),
        'ordinary_profiles_equal_before_speed_only_tuning': read(STAGE/'profile_analysis.json')['passed']
            and all(read(STAGE/'profile_analysis.json')['ordinary_profiles_equal'].values()),
        'all_105_original_models_preserved': len(models) == 105 and all(models.values()),
        'display_clone_only_changes_two_publication_rates':display_only,
        'both_trials_use_qualified_display_world':all(d.get('generated_hashes',{}).get('world.sdf')
            == sha(DISPLAY_SCENE/'world.sdf') for d in (n,f)),
        'ordinary_public_entry_preserved': sha(ROOT/'src/humbleble_ws/cooperative_transport_bringup/launch/compliance_contact_transport.launch.py')
            == before['src/humbleble_ws/cooperative_transport_bringup/launch/compliance_contact_transport.launch.py'],
        'ordinary_gate_profiles_restored': all(read(PRIOR/'generated'/(r+'_safety.json'))['max_base_velocity'] == [.01,.01,.02]
            for r in ('leader','follower')),
        'measured_forward_speed_only_expanded': all(read(normal/'profiles_used'/(r+'_safety.json'))['max_base_velocity'] == [1.05,.01,.02]
            for r in ('leader','follower')),
        'regression_passed': count >= 263 and 'failed' not in regression,
        'build_passed': '2 packages finished' in (STAGE/'build_force_memory.log').read_text(),
        'no_owned_processes_remaining': no_owned_processes(),
    }
    report = {'checkpoint':'CP-12 simulation-only 3 m / 0.1 m/s with local grip maintenance',
        'passed':all(checks.values()), 'test_count':count, 'checks':checks,
        'normal_trial':str(normal.relative_to(ROOT)), 'fault_trial':str(fault.relative_to(ROOT)),
        'scope':'one measured forward profile; hardware, turns, other distances and startup success rate unqualified'}
    (STAGE/'qualification_checks.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
    if not report['passed']:
        return 1
    source_files = {ROOT/path for path in before if not path.endswith('README.md')}
    source_files.update((ROOT/'src/humbleble_ws/cooperative_transport_bringup/launch/compliance_cp12_display_scene.launch.py',
        ROOT/'tools/cp12_display_scene.py',
        ROOT/'src/humbleble_ws/amir_compliance_control/test/test_local_force_memory.py',
        ROOT/'src/humbleble_ws/cooperative_transport_bringup/config/compliance_speed_gui.config', Path(__file__)))
    source_files.update(PRIOR/'generated'/name for name in
        ('leader.urdf','follower.urdf','world.sdf','leader_base_controller.yaml','follower_base_controller.yaml',
         'leader_controllers.yaml','follower_controllers.yaml','scene_staging.json','mimic_initialization.json'))
    source_files.update(DISPLAY_SCENE/name for name in
        ('leader.urdf','follower.urdf','world.sdf','leader_base_controller.yaml','follower_base_controller.yaml',
         'leader_controllers.yaml','follower_controllers.yaml','scene_staging.json','mimic_initialization.json',
         'display_only_equivalence.json'))
    source_files.update(ROOT/path for path in models)
    source_files.add(PRIOR/'metrology_02/calibration/calibration.json')
    evidence = {BASE/'result.json',BASE/'motion.json', STAGE/'qualification_checks.json',
                STAGE/'regression.log',STAGE/'build_force_memory.log',STAGE/'original_models_preserved.json',
                STAGE/'profile_analysis.json'}
    for folder in (normal,fault):
        evidence.update(folder/name for name in ('result.json','control_source_hashes.json','trial_source_hashes.json',
            'control_policy.json','leader_policy.json','original_profiles_restored.json','command.json'))
    manifest = {'schema_version':3,'passed':True,'simulation_only':True,'grip_maintenance':True,
        'publication_mode':'ASYNCHRONOUS','speed_m_s':.1,'distance_m':3.,
        'normal_trial':str(normal.relative_to(ROOT)), 'fault_trial':str(fault.relative_to(ROOT)),
        'base_speed_evidence':str(BASE.relative_to(ROOT)),
        'source_sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted(source_files)},
        'evidence_sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted(evidence)}}
    if args.write_release:
        (STAGE/'qualified_speed_010.json').write_text(json.dumps(manifest, indent=2))
        print('Released exactly 3 m / 0.1 m/s with mandatory local grip maintenance')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

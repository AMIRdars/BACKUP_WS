"""Separate, simulation-only 1 m forward / 1 m backwards contact carry."""
from datetime import datetime
import importlib.util
import json
from pathlib import Path
import uuid

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, EmitEvent, ExecuteProcess, LogInfo, OpaqueFunction, RegisterEventHandler
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch.substitutions import LaunchConfiguration


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


parent = load(Path(__file__).resolve().with_name('compliance_speed_trial.launch.py'), 'cp13_parent')
STAGE = Path('audits/whole_body_compliance_20261019/cp13_round_trip')


def qualification(root):
    original = parent.qualification(root)
    evidence = load(root/'tools/round_trip_evidence.py', 'cp13_evidence')
    return evidence.qualification(root, original), original


def completed(event, context, *, output):
    if context.is_shutdown:
        return []
    result = json.loads((output/'result.json').read_text())
    if event.returncode != 0 or not result.get('passed') or not result.get('round_trip_verified'):
        raise RuntimeError('CP-13 round trip failed; inspect '+str(output/'result.json'))
    return [LogInfo(msg='CP-13 PASSED: 1 m forward, stopped, 1 m backward, stopped. '+str(output/'result.json')),
            EmitEvent(event=Shutdown(reason='CP-13 round trip complete'))]


def setup(context):
    value = lambda key: LaunchConfiguration(key).perform(context)
    root = Path(value('workspace_directory')).expanduser().resolve()
    distance, speed = float(value('forward_distance_m')), float(value('translation_velocity_m_s'))
    if distance != 1. or speed != .1:
        raise ValueError('this separate entry supports exactly 1 m out / 1 m back, speed cap 0.1 m/s')
    for key in ('rotation_angle_deg','world_y_distance_m','translation_acceleration_m_s2',
                'angular_velocity_deg_s','angular_acceleration_deg_s2','return_distance_m'):
        if key in context.launch_configurations:
            raise ValueError('round-trip route and acceleration are fixed: '+key)
    domain = int(value('ros_domain_id'))
    if not 0 <= domain <= 232:
        raise ValueError('invalid ROS domain')
    _, original = qualification(root)
    output = (Path(value('output_directory')).expanduser().resolve() if value('output_directory')
              else root/STAGE/('launch_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')))
    if output.exists():
        raise ValueError('output directory already exists: '+str(output))
    partition = 'amir_cp9_round_trip_'+uuid.uuid4().hex[:12]
    env = {'ROS_DOMAIN_ID':str(domain),'ROS_LOCALHOST_ONLY':'1','IGN_PARTITION':partition,
           'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1',
           'PYTHONUNBUFFERED':'1','RMW_FASTRTPS_PUBLICATION_MODE':'ASYNCHRONOUS'}
    trial = ExecuteProcess(name='cp13_round_trip',cwd=str(root),additional_env=env,output='screen',
        sigterm_timeout='120',sigkill_timeout='10',cmd=['/usr/bin/python3',str(root/'tools/amir_round_trip_trial.py'),
            '--run-directory',str(root/parent.DISPLAY_SCENE),
            '--metrology-directory',str(root/parent.PRIOR/'metrology_02'),
            '--output',str(output),'--distance',str(distance),'--speed',str(speed),
            '--base-speed-evidence',str(root/original['base_speed_evidence'])])
    actions = [LogInfo(msg='CP-13 simulation: +1 m, stop/settle 12 sim s, -1 m, stop/settle. '
                           'Speed cap 0.1 m/s; existing reference acceleration 0.005 m/s2, peak about 0.071 m/s.'),
        LogInfo(msg='CP-13 output_directory: '+str(output)),
        LogInfo(msg=f'ROS_DOMAIN_ID={domain}, IGN_PARTITION={partition}'),
        RegisterEventHandler(OnProcessExit(target_action=trial,
            on_exit=lambda event,ctx:completed(event,ctx,output=output)))]
    if value('headless') == 'false':
        config = Path(get_package_share_directory('cooperative_transport_bringup'))/'config/compliance_speed_gui.config'
        if not config.is_file():
            raise ValueError('speed GUI config missing; rebuild cooperative_transport_bringup')
        gui_env = dict(env)
        if value('gui_nvidia_offload') == 'true':
            gui_env.update(__NV_PRIME_RENDER_OFFLOAD='1',__GLX_VENDOR_LIBRARY_NAME='nvidia')
        actions.append(ExecuteProcess(name='cp13_gazebo_gui',cwd=str(root),additional_env=gui_env,output='screen',
            sigterm_timeout='5',sigkill_timeout='5',cmd=['ign','gazebo','-g','--gui-config',str(config),'--force-version','6']))
    actions.append(trial)
    return actions


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('workspace_directory',default_value=parent.workspace()),
        DeclareLaunchArgument('headless',default_value='false',choices=['true','false']),
        DeclareLaunchArgument('gui_nvidia_offload',default_value='true',choices=['true','false']),
        DeclareLaunchArgument('forward_distance_m',default_value='1.0'),
        DeclareLaunchArgument('translation_velocity_m_s',default_value='0.1'),
        DeclareLaunchArgument('record_data',default_value='true',choices=['true']),
        DeclareLaunchArgument('output_directory',default_value=''),
        DeclareLaunchArgument('ros_domain_id',default_value='93'),
        OpaqueFunction(function=setup)])

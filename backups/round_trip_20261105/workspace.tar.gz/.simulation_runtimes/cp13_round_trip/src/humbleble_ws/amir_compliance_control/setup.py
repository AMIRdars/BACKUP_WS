from setuptools import setup
from glob import glob

setup(name='amir_compliance_control', version='0.1.0',
      packages=['amir_compliance_control'],
      data_files=[('share/ament_index/resource_index/packages', ['resource/amir_compliance_control']),
                  ('share/amir_compliance_control', ['package.xml', 'README.md']),
                  ('share/amir_compliance_control/launch', glob('launch/*.launch.py'))],
      install_requires=['setuptools', 'numpy'], zip_safe=True,
      maintainer='dars5070', maintainer_email='dars5070@todo.todo', license='Apache-2.0',
      entry_points={'console_scripts': [
          'local_grip_maintenance = amir_compliance_control.grip_maintenance:main',
          'native_grasp_monitor = amir_compliance_control.native_grasp:main',
          'follower_whole_body = amir_compliance_control.whole_body_node:main',
          'leader_planar_trajectory = amir_compliance_control.planar_leader:main',
          'actuator_interlock = amir_compliance_control.interlock:interlock_main',
          'controller_audit = amir_compliance_control.interlock:audit_main',
          'follower_arm_base = amir_compliance_control.arm_base:main',
          'follower_arm_admittance = amir_compliance_control.arm_admittance:main',
          'leader_trajectory_node = amir_compliance_control.transport:leader_main',
          'follower_hold = amir_compliance_control.transport:follower_main',
          'safety_gate = amir_compliance_control.safety:gate_main',
          'safety_supervisor = amir_compliance_control.safety:supervisor_main',
          'wrench_preprocessor = amir_compliance_control.wrench_preprocessor:main']})
